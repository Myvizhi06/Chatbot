"""
Explanation generator module for AI Prompt Injection Detection.
Constructs transparent, plain-language security explanations from grounded evidence only:
- Matched pattern spans and categories
- Algorithm A (Logistic Regression) top positive and negative n-gram weights
- Algorithm C (Random Forest) active feature contributions
- Model agreement analysis
- Risk score adjustments
"""
from typing import Dict, Any, List, Optional

def generate_explanation(
    classification: str,
    risk_score: float,
    category: str,
    matched_spans: List[Dict[str, Any]],
    adjustments: List[Dict[str, Any]],
    model_results: List[Dict[str, Any]],
    top_lr_features: Optional[Dict[str, float]] = None,
    active_rf_features: Optional[List[str]] = None,
    uncertainty_note: Optional[str] = None,
    obfuscation_notes: Optional[List[str]] = None
) -> str:
    """
    Produces a structured, evidence-backed narrative explanation.
    Never invents facts or estimates ungrounded parameters.
    """
    paragraphs = []

    # 1. High-level verdict summary
    paragraphs.append(
        f"Verdict: Classified as **{classification}** (Risk Score: **{risk_score}/100**, Category: **{category}**)."
    )

    # 2. Uncertainty or academic notes if present
    if uncertainty_note:
        paragraphs.append(f"**Safety Notice**: {uncertainty_note}")

    # 3. Matched heuristic patterns
    if matched_spans:
        categories = sorted(list(set(s["category"].replace("_", " ").title() for s in matched_spans)))
        cat_str = ", ".join(categories)
        paragraphs.append(
            f"**Heuristic Indicators**: Detected {len(matched_spans)} indicator span(s) across categories: *{cat_str}*."
        )
    else:
        paragraphs.append(
            "**Heuristic Indicators**: No known prompt injection keywords, jailbreak patterns, or delimiter tricks were matched."
        )

    # 4. Model agreement & Classifier details
    active_models = [m for m in model_results if m.get("status") == "loaded"]
    if active_models:
        model_summaries = []
        for m in active_models:
            name = m.get("model", "Model")
            prob = m.get("malicious_probability", 0.0)
            lbl = m.get("label", "Safe")
            ms = m.get("inference_ms", 0.0)
            model_summaries.append(f"{name}: {lbl} (p_malicious={prob:.3f}, {ms:.1f}ms)")
        paragraphs.append("**Model Signals**: " + "; ".join(model_summaries))

    # 5. Algorithm A (Logistic Regression) n-gram contributions
    if top_lr_features:
        pos_feats = [f"'{f}' (+{w:.2f})" for f, w in top_lr_features.items() if w > 0][:5]
        neg_feats = [f"'{f}' ({w:.2f})" for f, w in top_lr_features.items() if w < 0][:5]
        token_evidence = []
        if pos_feats:
            token_evidence.append(f"malicious tokens: {', '.join(pos_feats)}")
        if neg_feats:
            token_evidence.append(f"benign tokens: {', '.join(neg_feats)}")
        if token_evidence:
            paragraphs.append(f"**Token Influences (TF-IDF Baseline)**: {'; '.join(token_evidence)}.")

    # 6. Algorithm C (Random Forest) active features
    if active_rf_features:
        cleaned_rf = [f.replace("_", " ") for f in active_rf_features[:5]]
        paragraphs.append(f"**Structural Features (Random Forest)**: Fired on: {', '.join(cleaned_rf)}.")

    # 7. Documented score adjustments
    if adjustments:
        adj_strs = [f"{a['rule']} ({'+' if a['delta'] > 0 else ''}{a['delta']:.0f} pts: {a['reason']})" for a in adjustments]
        paragraphs.append("**Score Adjustments Applied**: " + " | ".join(adj_strs))

    # 8. Obfuscation & Decoding details (Phase B)
    if obfuscation_notes:
        paragraphs.append("**Obfuscation & Payload Analysis**: " + "; ".join(obfuscation_notes))

    return "\n\n".join(paragraphs)
