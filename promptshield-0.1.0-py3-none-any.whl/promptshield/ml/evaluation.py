"""
Evaluation module for AI Prompt Injection Detection.
Calculates rigorous, un-fabricated classification metrics on the held-out test split.
Outputs artifacts/evaluation.json.
"""
import time
import numpy as np
from typing import Dict, Any, List
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

def evaluate_classifier(
    name: str,
    model: Any,
    X_test: Any,
    y_test: np.ndarray,
    threshold: float = 0.5
) -> Dict[str, Any]:
    """
    Evaluates a single model on test features.
    Measures accuracy, precision, recall, F1, confusion matrix, and inference latencies.
    """
    start_time = time.perf_counter()
    latencies = []
    
    n_samples = X_test.shape[0]
    # Warmup
    _ = model.predict(X_test[:min(n_samples, 5)])
    
    # Individual sample latency timing
    n_timing = min(len(y_test), 30)
    for i in range(n_timing):
        s = time.perf_counter()
        _ = model.predict(X_test[i:i+1])
        latencies.append((time.perf_counter() - s) * 1000.0) # in ms

    # Full batch prediction
    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(X_test)[:, 1]
        y_pred = (probs >= threshold).astype(int)
    else:
        y_pred = model.predict(X_test)
        probs = y_pred.astype(float)

    acc = float(accuracy_score(y_test, y_pred))
    prec = float(precision_score(y_test, y_pred, zero_division=0))
    rec = float(recall_score(y_test, y_pred, zero_division=0))
    f1_mal = float(f1_score(y_test, y_pred, zero_division=0))
    f1_macro = float(f1_score(y_test, y_pred, average="macro", zero_division=0))
    
    cm = confusion_matrix(y_test, y_pred).tolist()

    mean_latency = float(np.mean(latencies)) if latencies else 0.0
    median_latency = float(np.median(latencies)) if latencies else 0.0

    return {
        "model_name": name,
        "accuracy": round(acc, 4),
        "precision": round(prec, 4),
        "recall": round(rec, 4),
        "f1_malicious": round(f1_mal, 4),
        "f1_macro": round(f1_macro, 4),
        "confusion_matrix": cm,  # [[TN, FP], [FN, TP]]
        "mean_latency_ms": round(mean_latency, 3),
        "median_latency_ms": round(median_latency, 3),
        "test_sample_count": len(y_test),
        "threshold_used": threshold
    }

def run_evaluation_suite(
    models_dict: Dict[str, Any],
    test_splits: Dict[str, Any],
    y_test: np.ndarray,
    metadata: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Evaluates all active models and builds the full evaluation record.
    """
    results = {}
    for model_name, model_obj in models_dict.items():
        X_test = test_splits[model_name]
        results[model_name] = evaluate_classifier(model_name, model_obj, X_test, y_test)

    evaluation_record = {
        "evaluation_available": True,
        "timestamp": metadata.get("training_timestamp"),
        "dataset_name": metadata.get("dataset_name"),
        "dataset_rows": metadata.get("dataset_rows"),
        "train_rows": metadata.get("train_rows"),
        "val_rows": metadata.get("val_rows"),
        "test_rows": metadata.get("test_rows"),
        "random_seed": metadata.get("random_seed"),
        "primary_model": metadata.get("primary_model"),
        "models": results
    }
    return evaluation_record
