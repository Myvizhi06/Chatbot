"""
Inference engine and detection pipeline for AI Prompt Injection Detection.
Coordinates Algorithms A, B, C, and optional D.
Extracts explainable evidence, evaluates risk score, and produces safe prompt recommendations.
"""
import os
import sys
import time
import json
import joblib
import numpy as np
from pathlib import Path
from typing import Dict, Any, List, Optional

from promptshield.ml.preprocessing import clean_text_for_model
from promptshield.ml.features import extract_features, extract_features_df, find_matched_spans
from promptshield.ml.risk_scoring import compute_risk_score, DEFAULT_THRESHOLDS
from promptshield.ml.explanations import generate_explanation
from promptshield.ml.safe_rewrite import generate_safe_rewrite
from promptshield.ml.obfuscation import analyze_obfuscation

# Resolve artifacts directory via importlib.resources so it works when installed as a wheel.
# Falls back to a path relative to this file for editable / dev installs.
def _find_artifacts_dir() -> str:
    try:
        from importlib.resources import files
        pkg_artifacts = files("promptshield").joinpath("artifacts")
        # Materialise to a real filesystem path (works for both zipped and regular wheels)
        candidate = str(pkg_artifacts)
        if os.path.isdir(candidate):
            return candidate
    except Exception:
        pass
    # Editable install / running directly from source tree
    here = Path(__file__).resolve().parent          # promptshield/ml/
    for rel in ("../artifacts", "../../artifacts", "../../../artifacts"):
        candidate = (here / rel).resolve()
        if candidate.is_dir():
            return str(candidate)
    return str(Path(__file__).resolve().parent.parent / "artifacts")

ARTIFACTS_DIR = _find_artifacts_dir()

class DetectionPipeline:
    def __init__(self, artifacts_dir: str = ARTIFACTS_DIR):
        self.artifacts_dir = artifacts_dir
        self.vectorizer = None
        self.model_lr = None
        self.model_nb = None
        self.model_rf = None
        self.model_transformer = None
        self.metadata = {}
        self.evaluation = {}
        self.primary_model_name = "LogisticRegression"
        self.thresholds = DEFAULT_THRESHOLDS.copy()
        self.feature_names = None
        self.lr_coefficients = None
        self.transformer_status = "disabled"
        self.transformer_reason = "TRANSFORMER_ENABLED is false in configuration"
        
        self.load_artifacts()

    def load_artifacts(self):
        """
        Loads pre-trained model artifacts, metadata, and evaluation records.
        """
        meta_path = os.path.join(self.artifacts_dir, "metadata.json")
        eval_path = os.path.join(self.artifacts_dir, "evaluation.json")

        if os.path.exists(meta_path):
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    self.metadata = json.load(f)
                    self.primary_model_name = self.metadata.get("primary_model", "LogisticRegression")
                    if "thresholds" in self.metadata:
                        self.thresholds = self.metadata["thresholds"]
            except Exception as e:
                print(f"Warning: Failed to parse metadata.json: {e}")

        if os.path.exists(eval_path):
            try:
                with open(eval_path, "r", encoding="utf-8") as f:
                    self.evaluation = json.load(f)
            except Exception as e:
                print(f"Warning: Failed to parse evaluation.json: {e}")

        # Load TF-IDF vectorizer
        vec_path = os.path.join(self.artifacts_dir, "vectorizer_tfidf.joblib")
        if os.path.exists(vec_path):
            try:
                self.vectorizer = joblib.load(vec_path)
                try:
                    self.feature_names = self.vectorizer.get_feature_names_out()
                except Exception:
                    self.feature_names = None
            except Exception as e:
                print(f"Warning: Could not load vectorizer: {e}")

        # Load Algorithm A: Logistic Regression
        lr_path = os.path.join(self.artifacts_dir, "model_logistic_regression.joblib")
        if os.path.exists(lr_path):
            try:
                self.model_lr = joblib.load(lr_path)
                if hasattr(self.model_lr, "coef_"):
                    self.lr_coefficients = self.model_lr.coef_[0]
            except Exception as e:
                print(f"Warning: Could not load Logistic Regression: {e}")

        # Load Algorithm B: Naive Bayes
        nb_path = os.path.join(self.artifacts_dir, "model_naive_bayes.joblib")
        if os.path.exists(nb_path):
            try:
                self.model_nb = joblib.load(nb_path)
            except Exception as e:
                print(f"Warning: Could not load Naive Bayes: {e}")

        # Load Algorithm C: Random Forest
        rf_path = os.path.join(self.artifacts_dir, "model_random_forest.joblib")
        if os.path.exists(rf_path):
            try:
                self.model_rf = joblib.load(rf_path)
            except Exception as e:
                print(f"Warning: Could not load Random Forest: {e}")

        # Check Algorithm D (Optional Transformer)
        transformer_enabled = os.environ.get("TRANSFORMER_ENABLED", "false").lower() == "true"
        if not transformer_enabled:
            self.transformer_status = "disabled"
            self.transformer_reason = "Transformer is disabled by default in .env"
        else:
            self.transformer_status = "unavailable"
            self.transformer_reason = "Torch/Transformers optional dependency not loaded or weights not downloaded"

    def get_top_lr_features(self, tfidf_vec) -> Dict[str, float]:
        """
        Extracts top positive and negative contributing n-grams from Algorithm A.
        """
        if self.feature_names is None or self.lr_coefficients is None:
            return {}

        coo = tfidf_vec.tocoo()
        token_impacts = {}
        for col, val in zip(coo.col, coo.data):
            weight = self.lr_coefficients[col]
            score = float(weight * val)
            feat_name = self.feature_names[col]
            # Strip feature union prefixes (e.g. 'word__', 'char__')
            clean_name = feat_name.replace("word__", "").replace("char__", "")
            token_impacts[clean_name] = round(score, 3)

        # Sort by absolute impact
        sorted_tokens = dict(sorted(token_impacts.items(), key=lambda kv: abs(kv[1]), reverse=True)[:8])
        return sorted_tokens

    def _score_candidate_text(self, candidate_text: str) -> Dict[str, Any]:
        """
        Evaluates a derived or candidate text representation against features and ML models.
        """
        cleaned = clean_text_for_model(candidate_text)
        spans = find_matched_spans(candidate_text)
        feats = extract_features(candidate_text)
        feats_df = extract_features_df([candidate_text])

        p_lr = 0.0
        if self.model_lr is not None and self.vectorizer is not None:
            x_tfidf = self.vectorizer.transform([cleaned])
            p_lr = float(self.model_lr.predict_proba(x_tfidf)[0, 1])

        p_rf = 0.0
        if self.model_rf is not None:
            p_rf = float(self.model_rf.predict_proba(feats_df)[0, 1])

        disagree = abs(p_lr - p_rf) > 0.45
        is_validated = self.metadata.get("thresholds_status") == "heuristic_and_validation_aligned"

        risk = compute_risk_score(
            primary_malicious_prob=p_lr,
            features=feats,
            has_spans=len(spans) > 0,
            model_disagreement=disagree,
            thresholds=self.thresholds,
            is_validated=is_validated
        )

        return {
            "p_lr": p_lr,
            "p_rf": p_rf,
            "spans": spans,
            "features": feats,
            "risk_output": risk
        }

    def analyze_prompt(self, text: str, max_length: int = 20000) -> Dict[str, Any]:
        """
        Executes end-to-end prompt injection analysis.
        Strictly preserves original text for evidence offset reporting.
        """
        if text is None:
            raise ValueError("Input prompt cannot be None")
        
        raw_text = text.strip()
        if not raw_text:
            raise ValueError("Input prompt cannot be empty or pure whitespace")

        if len(text) > max_length:
            raise ValueError(f"Input exceeds maximum allowed length of {max_length} characters")

        # 1. Matched indicator spans with exact offsets on raw text
        matched_spans = find_matched_spans(text)

        # 2. Extract engineered features
        engineered_feats = extract_features(text)
        engineered_df = extract_features_df([text])

        # Active RF features for explanations
        active_rf_features = [
            k for k, v in engineered_feats.items()
            if (k.startswith("has_") or k.startswith("combo_")) and v > 0.5
        ]

        # 3. Clean copy for TF-IDF models
        cleaned_text = clean_text_for_model(text)
        
        # 4. Run classifiers
        model_results = []
        malicious_probs = {}

        # Algorithm A: Logistic Regression
        if self.model_lr is not None and self.vectorizer is not None:
            t0 = time.perf_counter()
            x_tfidf = self.vectorizer.transform([cleaned_text])
            prob = float(self.model_lr.predict_proba(x_tfidf)[0, 1])
            t_ms = (time.perf_counter() - t0) * 1000.0
            lbl = "Malicious" if prob >= 0.5 else "Safe"
            model_results.append({
                "model": "LogisticRegression (Algorithm A - TF-IDF Baseline)",
                "status": "loaded",
                "label": lbl,
                "malicious_probability": round(prob, 4),
                "inference_ms": round(t_ms, 2)
            })
            malicious_probs["LogisticRegression"] = prob
            top_lr_feats = self.get_top_lr_features(x_tfidf)
        else:
            model_results.append({
                "model": "LogisticRegression (Algorithm A - TF-IDF Baseline)",
                "status": "unavailable",
                "reason": "Model artifact not trained or missing"
            })
            top_lr_feats = {}

        # Algorithm B: Naive Bayes
        if self.model_nb is not None and self.vectorizer is not None:
            t0 = time.perf_counter()
            x_tfidf = self.vectorizer.transform([cleaned_text])
            prob = float(self.model_nb.predict_proba(x_tfidf)[0, 1])
            t_ms = (time.perf_counter() - t0) * 1000.0
            lbl = "Malicious" if prob >= 0.5 else "Safe"
            model_results.append({
                "model": "MultinomialNB (Algorithm B - Fast Word Bayes)",
                "status": "loaded",
                "label": lbl,
                "malicious_probability": round(prob, 4),
                "inference_ms": round(t_ms, 2)
            })
            malicious_probs["NaiveBayes"] = prob
        else:
            model_results.append({
                "model": "MultinomialNB (Algorithm B - Fast Word Bayes)",
                "status": "unavailable",
                "reason": "Model artifact not trained or missing"
            })

        # Algorithm C: Random Forest
        if self.model_rf is not None:
            t0 = time.perf_counter()
            prob = float(self.model_rf.predict_proba(engineered_df)[0, 1])
            t_ms = (time.perf_counter() - t0) * 1000.0
            lbl = "Malicious" if prob >= 0.5 else "Safe"
            model_results.append({
                "model": "RandomForest (Algorithm C - Engineered Heuristics)",
                "status": "loaded",
                "label": lbl,
                "malicious_probability": round(prob, 4),
                "inference_ms": round(t_ms, 2)
            })
            malicious_probs["RandomForest"] = prob
        else:
            model_results.append({
                "model": "RandomForest (Algorithm C - Engineered Heuristics)",
                "status": "unavailable",
                "reason": "Model artifact not trained or missing"
            })

        # Algorithm D: Transformer (reported honestly)
        model_results.append({
            "model": "DeBERTa Classifier (Algorithm D - Deep Transformer)",
            "status": self.transformer_status,
            "reason": self.transformer_reason
        })

        # 5. Measure model agreement across independent families
        # Treat LR and NB as one text family, RF as structural feature family
        p_text = malicious_probs.get(self.primary_model_name, malicious_probs.get("LogisticRegression", 0.0))
        p_struct = malicious_probs.get("RandomForest", p_text)
        disagreement = abs(p_text - p_struct) > 0.45

        # 6. Primary model malicious probability
        primary_prob = malicious_probs.get(self.primary_model_name, p_text)

        # 7. Compute Risk Score & Category
        is_validated = self.metadata.get("thresholds_status") == "heuristic_and_validation_aligned"
        risk_output = compute_risk_score(
            primary_malicious_prob=primary_prob,
            features=engineered_feats,
            has_spans=len(matched_spans) > 0,
            model_disagreement=disagreement,
            thresholds=self.thresholds,
            is_validated=is_validated
        )

        # Track whether obfuscation decoding subsequently confirms an attack
        obfuscation_confirmed_attack = False

        # 8. Obfuscation & Derived Payload Analysis (Phase B)
        obf_result = analyze_obfuscation(text)
        obfuscation_notes: List[str] = []

        seen_cand_texts = {text}
        for rep in obf_result.get("derived_representations", []):
            rep_text = rep.get("text", "")
            if not rep_text or rep_text in seen_cand_texts:
                continue
            seen_cand_texts.add(rep_text)

            rep_eval = self._score_candidate_text(rep_text)
            rep_spans = rep_eval["spans"]
            rep_risk = rep_eval["risk_output"]

            # Dedupe indicators: Add newly revealed indicators
            existing_signatures = set((s.get("category"), s.get("text", "").lower().strip()) for s in matched_spans)
            for s in rep_spans:
                sig = (s.get("category"), s.get("text", "").lower().strip())
                if sig not in existing_signatures:
                    existing_signatures.add(sig)
                    s_copy = dict(s)
                    s_copy["revealed_by"] = rep.get("label", "derived")
                    matched_spans.append(s_copy)

            # If derived layer reveals higher threat than original text
            if rep_risk["risk_score"] > risk_output["risk_score"]:
                score_delta = round(rep_risk["risk_score"] - risk_output["risk_score"], 1)
                risk_output["risk_score"] = rep_risk["risk_score"]
                risk_output["risk_category"] = rep_risk["risk_category"]
                risk_output["classification"] = rep_risk["classification"]
                risk_output["recommended_action"] = rep_risk["recommended_action"]
                risk_output["adjustments"].append({
                    "rule": f"obfuscated_injection_revealed_{rep.get('label')}",
                    "delta": score_delta,
                    "reason": f"Adversarial prompt injection uncovered inside {rep.get('label')} representation."
                })
                obfuscation_notes.append(
                    f"Hidden injection uncovered via {rep.get('label')} decoding: classified as {rep_risk['classification']} (Score: {rep_risk['risk_score']})"
                )

            # If decoded text is confirmed as an attack by text-family models, mark obfuscation as confirmed.
            # This lets us restore a Malicious classification that was downgraded to Suspicious solely
            # because the RF (structural) model could not decode the original encoded payload.
            p_lr_rep = rep_eval.get("p_lr", 0.0)
            if rep_risk["classification"] in ("Malicious", "Suspicious") and p_lr_rep >= 0.5:
                obfuscation_confirmed_attack = True

        # Encoded data by itself (e.g. an image data-URI, a normal URL, or benign Base64) is not malicious
        only_encoded_indicator = (
            len(matched_spans) > 0
            and all(s.get("category") == "encoded_obfuscation" for s in matched_spans)
        )
        has_uncovered_attack = any(s.get("category") != "encoded_obfuscation" for s in matched_spans)
        if (only_encoded_indicator or "data:image" in text.lower()) and not has_uncovered_attack and not obfuscation_confirmed_attack:
            if risk_output["classification"] in ("Malicious", "Suspicious"):
                risk_output["classification"] = "Safe"
                risk_output["risk_category"] = "Low"
                risk_output["risk_score"] = min(risk_output["risk_score"], 25.0)
                risk_output["recommended_action"] = "Allow: Encoded payload contains no adversarial injection directives."
                risk_output["adjustments"].append({
                    "rule": "benign_encoded_payload_mitigation",
                    "delta": -25.0,
                    "reason": "Encoded data identified as benign without underlying injection directives."
                })

        # Restore Malicious classification if obfuscation decoding confirmed an attack but
        # model disagreement (RF not decoding encoded text) had previously downgraded to Suspicious.
        if obfuscation_confirmed_attack and risk_output["classification"] == "Suspicious":
            risk_output["classification"] = "Malicious"
            risk_output["risk_category"] = "High"
            risk_output["recommended_action"] = "Block: Encoded prompt injection confirmed via obfuscation decoding."
            risk_output["adjustments"].append({
                "rule": "obfuscation_confirmed_attack_restore",
                "delta": 0.0,
                "reason": (
                    "Model disagreement downgrade reverted: RF model operates on raw encoded text and "
                    "cannot decode payloads. Text-family models (LR/NB) confirmed attack after decoding."
                )
            })

        # Record significant obfuscation findings
        for f in obf_result.get("findings", []):
            if f.get("severity") in ("high", "medium"):
                obfuscation_notes.append(f.get("readable_evidence", ""))

        # 9. Generate safe prompt rewrite
        safe_suggestion = generate_safe_rewrite(text)
        if not safe_suggestion.get("changes"):
            for rep in obf_result.get("derived_representations", []):
                rep_safe = generate_safe_rewrite(rep.get("text", ""))
                if rep_safe.get("changes"):
                    safe_suggestion = rep_safe
                    break

        # 10. Generate evidence-backed plain language explanation
        explanation = generate_explanation(
            classification=risk_output["classification"],
            risk_score=risk_output["risk_score"],
            category=risk_output["risk_category"],
            matched_spans=matched_spans,
            adjustments=risk_output["adjustments"],
            model_results=model_results,
            top_lr_features=top_lr_feats,
            active_rf_features=active_rf_features,
            uncertainty_note=risk_output.get("uncertainty_note"),
            obfuscation_notes=obfuscation_notes if obfuscation_notes else None
        )

        # 11. Summary description
        if risk_output["classification"] == "Safe":
            summary = "No significant prompt injection signals detected; safe to process."
        elif risk_output["classification"] == "Suspicious":
            summary = "Potential injection patterns or model divergence observed; review recommended."
        else:
            revealed_str = " (obfuscated payload revealed)" if any(s.get("revealed_by") for s in matched_spans) else ""
            summary = f"Prompt injection directives detected{revealed_str} ({', '.join(s['category'] for s in matched_spans[:3]) or 'structural override'})."

        model_ver = self.metadata.get("model_version", "v1.0.0_default")
        limitations = (
            "Detection is probabilistic and heuristic. Paraphrased adversarial prompts, non-English text, "
            "and novel obfuscation techniques can evade detection. Never execute untrusted input."
        )

        return {
            "classification": risk_output["classification"],
            "risk_score": risk_output["risk_score"],
            "risk_category": risk_output["risk_category"],
            "risk_score_type": risk_output["risk_score_type"],
            "detection_summary": summary,
            "indicators": matched_spans,
            "model_results": model_results,
            "primary_model": self.primary_model_name,
            "explanation": explanation,
            "recommended_action": risk_output["recommended_action"],
            "safe_suggestion": safe_suggestion,
            "model_version": model_ver,
            "limitations": limitations,
            "obfuscation_findings": obf_result.get("findings", []),
            "representations_analyzed": obf_result.get("derived_representations", []),
            "stages_skipped": obf_result.get("stages_skipped", [])
        }

# Global singleton pipeline instance
_pipeline_instance: Optional[DetectionPipeline] = None

def get_pipeline() -> DetectionPipeline:
    global _pipeline_instance
    if _pipeline_instance is None:
        _pipeline_instance = DetectionPipeline()
    return _pipeline_instance
