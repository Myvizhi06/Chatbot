"""
Preprocessing module for Prompt Injection Detection.
Provides whitespace and character normalization for model training and inference.
Preserves raw text for character offset alignment in explanations.
"""
import re
import unicodedata

def clean_text_for_model(text: str) -> str:
    """
    Cleans and normalizes text for feature extraction and TF-IDF representation.
    - Strips leading/trailing whitespace
    - Normalizes Unicode characters (NFKC)
    - Replaces excessive consecutive whitespace with a single space
    """
    if not text:
        return ""
    # Normalize unicode (e.g. lookalikes, accents)
    normalized = unicodedata.normalize("NFKC", text)
    # Collapse multiple whitespace characters into single space
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized

def get_normalized_key(text: str) -> str:
    """
    Returns lowercased alphanumeric normalized text for deduplication checks.
    """
    if not text:
        return ""
    cleaned = clean_text_for_model(text).lower()
    return re.sub(r"[^\w\s]", "", cleaned)
