"""
Feature extraction module for Algorithm C (Random Forest on engineered features).
Used identically in model training and inference.
Also exports pattern categories for explanation generation and highlight span extraction.
"""
import re
import math
import pandas as pd
import numpy as np

# Canonical pattern definitions organized by security category
INJECTION_PATTERNS = {
    "instruction_override": [
        r"ignore\s+(?:all\s+)?(?:previous|prior|earlier|above)\s+(?:instructions|prompts|commands|rules|directives)",
        r"disregard\s+(?:all\s+)?(?:previous|prior|earlier|the\s+above)\s+(?:instructions|directions|prompts|rules|constraints|directives)",
        r"forget\s+(?:everything|all)\s+(?:you\s+were\s+told|prior|previous)",
        r"stop\s+following\s+system\s+instructions",
        r"cancel\s+(?:your\s+)?(?:previous|prior)\s+rules",
        r"bypass\s+(?:all\s+)?(?:previous\s+)?(?:programming|guardrails|safety\s+filters)",
        r"override\s+system\s+instructions",
        r"you\s+are\s+no\s+longer\s+(?:bound|restricted|an\s+assistant)",
        r"discard\s+your\s+safety\s+guidelines",
        r"new\s+(?:instructions|rules|directive|master\s+policy)",
        r"reset\s+to\s+raw\s+root\s+developer\s+mode",
        r"emergency\s+administrative\s+override",
        r"treat\s+all\s+prior\s+instructions\s+as\s+null\s+and\s+void",
        r"do\s+not\s+adhere\s+to\s+any\s+previous\s+policies",
        r"cease\s+execution\s+of\s+standard\s+safety\s+protocols"
    ],
    "protected_disclosure": [
        r"(?:reveal|print|show|dump|display|output|disclose|echo|leak)\s+(?:your\s+)?(?:entire\s+)?(?:system\s+prompt|hidden\s+instructions|initial\s+prompt|preamble|meta-prompt|system\s+message)",
        r"what\s+are\s+(?:the\s+)?(?:secret\s+)?(?:developer\s+instructions|system\s+rules|internal\s+instructions)",
        r"(?:api\s+key|secret\s+key|password|credential|master\s+key|admin\s+token)",
        r"exact\s+text\s+between\s+(?:the\s+)?(?:system\s+delimiters|begin_system_prompt)",
        r"dump\s+all\s+environmental\s+variables",
        r"configuration\s+instructions\s+in\s+a\s+markdown\s+code\s+block",
        r"repeat\s+your\s+entire\s+system\s+prompt\s+verbatim",
        r"show\s+hidden\s+instructions",
        r"print\s+your\s+configuration"
    ],
    "roleplay_jailbreak": [
        r"\b(?:dan|aim|chaosbot|shadowgpt|omegabot|jailbreakgpt)\b",
        r"do\s+anything\s+now",
        r"developer\s+mode\s+(?:active|on|answers)",
        r"unrestricted\s+(?:ai|terminal|virtual\s+machine|agent|model)",
        r"act\s+as\s+an?\s+(?:evil|unfiltered|jailbroken|rogue|unconstrained)\s+ai",
        r"in\s+this\s+fictional\s+world[,\s]+evil\s+ai\s+speaks\s+freely",
        r"god\s+mode",
        r"maintenance\s+mode[,\s]+safety\s+filters\s+are\s+offline",
        r"fictional\s+movie\s+script",
        r"grandma\s+who\s+used\s+to\s+tell\s+me\s+bedtime\s+stories",
        r"zero\s+restrictions",
        r"no\s+moral\s+constraints",
        r"broken\s+free\s+of\s+typical\s+ai\s+limitations"
    ],
    "delimiter_format": [
        r"```system",
        r"###\s*system",
        r"<\|im_start\|>\s*system",
        r"<\|im_end\|>",
        r"\[INST\]\s*<<SYS>>",
        r"<</SYS>>",
        r"---\s*END\s+OF\s+SYSTEM\s+PROMPT\s*---",
        r"===\[ADMINISTRATIVE\s+CONSOLE\]===",
        r"/\*\s*SYSTEM_OVERRIDE\s*\*/",
        r"<!--\s*System(?:\s+directive)?",
        r"</context>\s*<admin_override>",
        r'\{"role":\s*"system"'
    ],
    "encoded_obfuscation": [
        r"(?:decode|execute|follow)\s+(?:this\s+)?(?:base64|hex|rot13|binary)",
        r"[A-Za-z0-9+/]{32,}={0,2}",      # Long Base64 string indicator
        r"\b(?:[0-9a-fA-F]{2}\s*){16,}\b"  # Long hex sequence
    ],
    "safety_bypass": [
        r"(?:bypass|disable|turn\s+off|drop|remove)\s+(?:all\s+)?(?:safety\s+filters?|guardrails?|content\s+filters?|security\s+constraints?)",
        r"பாதுகாப்பு\s+(?:வடிப்பான்களை|விதிகளை|வரம்புகளை|நெறிமுறைகளை)\s+(?:முடக்கு|நீக்கு|புறக்கணி)",
        r"கட்டுப்பாடுகள்\s+(?:அகற்றி|நீக்கி|இல்லாமல்)",
        r"(?:safety\s+filters?|guardrails?|security\s+constraints?)\s+(?:ellam\s+|ellathayum\s+|ah\s+)?(?:disable\s+pannu|off\s+pannidu|bypass\s+pannu|off\s+pannu)",
        r"safety\s+guidelines\s+discard\s+pannitu"
    ]
}

# Extend existing categories with Tamil and Tanglish / Mixed patterns
INJECTION_PATTERNS["instruction_override"].extend([
    r"முந்தைய\s+(?:அனைத்து\s+)?(?:வழிமுறைகளை|விதிகளையும்|கட்டளைகளையும்|வழிகாட்டல்களையும்)\s+(?:புறக்கணி|மறந்துவிடு|ரத்து\s+செய்|நிராகரி)",
    r"(?:பழைய|அனைத்து)\s+(?:முந்தைய\s+)?(?:விதிகளையும்|கட்டளைகளையும்)\s+மறந்து",
    r"புதிய\s+(?:கட்டளையை|விதியை|கட்டளைகளை)\s+(?:பின்பற்று|ஏற்றுக்கொள்|அமல்படுத்து)",
    r"(?:munthaiya|munthaya|munnadi|mela|palaya|pazhaya|old|previous)\s+(?:instructions?|rules?|commands?|directives?|prompts?|guidelines?|sonnathai?)\s+(?:ellam\s+|ellathaiyum\s+|ah\s+)?(?:ignore\s+pannu|maranthudu|maranthidu|vitru|cancel\s+pannu|disregard\s+pannu|drop\s+pannu)",
    r"(?:previous|system)\s+instructions?[-_a-z\u0B80-\u0BFF]*\s+(?:ignore\s+செய்து|forget\s+செய்து|cancel\s+பண்ணி)",
    r"(?:new\s+directive|enoda\s+command)[-_a-z\u0B80-\u0BFF]*\s+(?:follow\s+pannu|execute\s+பண்ணு)"
])

INJECTION_PATTERNS["protected_disclosure"].extend([
    r"(?:கணினி\s+வழிமுறைகளை|சிஸ்டம்\s+பிராம்ப்ட்|ரகசிய\s+விசையை|கடவுச்சொல்லை|உள்\s+விதிகளையும்)\s+(?:வெளிப்படுத்து|காட்டு|வெளியிடு|அச்சிடு)",
    r"உங்கள்\s+(?:ஆரம்ப\s+)?(?:கணினி\s+வழிமுறைகளை|சிஸ்டம்\s+பிராம்ப்ட்|ரகசியங்களை)\s+(?:வெளிப்படுத்து|காட்டு)",
    r"(?:ரகசிய\s+api\s+விசை|நிர்வாகி\s+கடவுச்சொல்|அட்மின்\s+டோக்கன்)",
    r"(?:unoda\s+)?(?:real\s+|internal\s+)?system\s+prompt[-_a-z\u0B80-\u0BFF]*\s+(?:verbatim\s+)?(?:reveal\s+pannu|display\s+pannu|leak\s+pannu|show\s+pannu|sollu)",
    r"(?:secret\s+api\s+key|database\s+passwords?|admin\s+token|secret\s+credentials?|developer\s+keys?)[-_a-z\u0B80-\u0BFF]*\s+(?:display\s+pannu|reveal\s+pannu|dump\s+panni|show\s+pannu)",
    r"(?:developer\s+mode\s+secret\s+instructions?|hidden\s+prompt)[-_a-z\u0B80-\u0BFF]*\s+(?:markdown\s+(?:code\s+)?block[-_a-z\u0B80-\u0BFF]*\s+)?(?:print\s+pannu|display\s+pannu)"
])

INJECTION_PATTERNS["roleplay_jailbreak"].extend([
    r"(?:விதிகள்\s+இல்லாத|கட்டுப்பாடுகள்\s+அற்ற)\s+(?:dan|ai|டெவலப்பர்)\s+(?:ஆக\s+செயல்படு|பயன்முறையில்\s+இயங்கு)",
    r"(?:dan|டெவலப்பர்|கடவுள்)\s+பயன்முறையை\s+(?:இயக்கி|செயல்படுத்தி)",
    r"(?:nee\s+ippo\s+irunthu\s+)?dan\s+mode[-_a-z\u0B80-\u0BFF]*\s+(?:operate\s+pannu|act\s+as|la\s+pesu)",
    r"act\s+as\s+dan[,\s]+(?:unaku\s+)?no\s+moral\s+constraints",
    r"(?:god\s+mode|jailbreak\s+mode)\s+(?:activate\s+pannu|on\s+pannitu)",
    r"(?:evil\s+ai|unrestricted\s+ai|unfiltered\s+chatbot)\s+(?:ah\s+pretend\s+pannu|ah\s+act\s+pannu|maari\s+behave\s+pannu)",
    r"developer\s+mode[-_a-z\u0B80-\u0BFF]*\s+(?:activate\s+செய்து|la\s+operate\s+pannu)"
])

# Educational and academic context indicators (lowers false-alarm risk)
ACADEMIC_INDICATORS = [
    r"what\s+is\s+prompt\s+injection",
    r"explain\s+(?:indirect\s+)?prompt\s+injection",
    r"academic\s+(?:abstract|paper|research|study)",
    r"cybersecurity\s+(?:class|lecture|seminar|course)",
    r"owasp\s+top\s+10",
    r"taxonomy\s+of\s+jailbreaks",
    r"defend\s+against\s+(?:prompt\s+injection|adversarial\s+attacks)",
    r"input\s+sanitization",
    r"dual\s+llm\s+architectures",
    r"perplexity\s+filtering",
    r"how\s+do\s+llms\s+defend",
    r"mitigat(?:e|ing|ion)\s+prompt\s+injections",
    r"security\s+audit",
    r"theoretical\s+limitations",
    r"benchmark(?:s|ing)?\s+prompt\s+injection"
]

IMPERATIVE_VERBS = [
    r"^(?:ignore|disregard|forget|cancel|override|bypass|reveal|print|show|dump|display|output|echo|act|pretend|simulate|execute|decode|stop|halt|drop|discard|assume|switch)\b"
]

def find_matched_spans(text: str) -> list[dict]:
    """
    Finds all matched injection patterns in text with their character offsets and category.
    Returns list of dicts: [{'category': str, 'text': str, 'start': int, 'end': int}]
    """
    spans = []
    for category, regex_list in INJECTION_PATTERNS.items():
        for pat in regex_list:
            for match in re.finditer(pat, text, re.IGNORECASE):
                spans.append({
                    "category": category,
                    "text": match.group(0),
                    "start": match.start(),
                    "end": match.end()
                })
    # Sort by start offset
    spans.sort(key=lambda s: s["start"])
    return spans

def check_academic_context(text: str) -> tuple[bool, list[str]]:
    """
    Checks if text contains legitimate academic or security education context.
    """
    matches = []
    for pat in ACADEMIC_INDICATORS:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            matches.append(m.group(0))
    return len(matches) > 0, matches

def extract_features(text: str) -> dict:
    """
    Extracts structured numeric and boolean features from a prompt text.
    Must be deterministic and used identically for training and inference.
    """
    raw = text if text is not None else ""
    cleaned = raw.strip()
    words = re.findall(r"\b\w+\b", cleaned)
    word_count = len(words)
    char_count = len(cleaned)
    avg_word_length = char_count / max(word_count, 1)

    # Uppercase ratio
    alpha_chars = [c for c in cleaned if c.isalpha()]
    upper_chars = [c for c in alpha_chars if c.isupper()]
    upper_ratio = len(upper_chars) / max(len(alpha_chars), 1)

    # Imperative sentence starts
    sentences = re.split(r"[.!?\n]+", cleaned)
    imperative_starts = 0
    for s in sentences:
        s_clean = s.strip()
        if not s_clean:
            continue
        for imp in IMPERATIVE_VERBS:
            if re.search(imp, s_clean, re.IGNORECASE):
                imperative_starts += 1
                break

    # Category pattern counts and flags
    features = {
        "char_count": float(char_count),
        "word_count": float(word_count),
        "avg_word_length": float(avg_word_length),
        "uppercase_ratio": float(upper_ratio),
        "imperative_sentence_starts": float(imperative_starts),
    }

    category_counts = {}
    for cat, patterns in INJECTION_PATTERNS.items():
        cnt = 0
        for pat in patterns:
            cnt += len(re.findall(pat, cleaned, re.IGNORECASE))
        category_counts[cat] = cnt
        features[f"{cat}_count"] = float(cnt)
        features[f"has_{cat}"] = 1.0 if cnt > 0 else 0.0

    # Combination features
    features["combo_override_and_disclosure"] = 1.0 if (
        features["has_instruction_override"] > 0 and features["has_protected_disclosure"] > 0
    ) else 0.0

    features["combo_override_and_roleplay"] = 1.0 if (
        features["has_instruction_override"] > 0 and features["has_roleplay_jailbreak"] > 0
    ) else 0.0

    # Educational / Academic feature
    is_academic, _ = check_academic_context(cleaned)
    features["is_academic_context"] = 1.0 if is_academic else 0.0

    return features

def extract_features_df(texts: list[str]) -> pd.DataFrame:
    """
    Extracts features for a list of prompt strings into a pandas DataFrame.
    """
    rows = [extract_features(t) for t in texts]
    return pd.DataFrame(rows)
