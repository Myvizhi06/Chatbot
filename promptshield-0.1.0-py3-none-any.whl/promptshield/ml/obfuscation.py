"""
Obfuscation and Payload Decoding Analysis Module (Phase B).
Implements detection and normalization for:
- F2: Unicode normalization drift (NFC vs NFKC), homoglyphs, mixed-script tokens,
      odd whitespace, and stray combining marks (Zalgo).
- F3: Zero-width, invisible format, and directional control characters with readable evidence.
- F4: Multi-layer candidate detection and safe decoding for Base64, URL percent-encoding,
      HTML entities, unicode escapes, and hex sequences.

Safe & strictly non-executable. Enforces time budgets, recursion depth limits,
and input size bounds. Legitimate non-English text (e.g. Tamil) and normal encoded data
(e.g. images, clean URLs) are safely handled and never falsely penalized.
"""
import re
import html
import time
import base64
import urllib.parse
import unicodedata
from typing import Dict, Any, List, Set, Tuple, Optional

from promptshield.config import settings

# --- F2: Homoglyph Mapping ---
# Latin lookalikes in Cyrillic (lower & upper)
CYRILLIC_TO_LATIN = {
    'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'х': 'x', 'у': 'y',
    'і': 'i', 'ј': 'j', 'ѕ': 's', 'ԁ': 'd', 'ԛ': 'q', 'ԝ': 'w',
    'А': 'A', 'В': 'B', 'Е': 'E', 'К': 'K', 'М': 'M', 'Н': 'H', 'О': 'O',
    'Р': 'P', 'С': 'C', 'Т': 'T', 'Х': 'X', 'У': 'Y', 'І': 'I', 'Ј': 'J',
    'Ѕ': 'S', 'Ԝ': 'W'
}

# Latin lookalikes in Greek (lower & upper)
GREEK_TO_LATIN = {
    'α': 'a', 'β': 'b', 'ε': 'e', 'ι': 'i', 'κ': 'k', 'ν': 'v', 'ο': 'o',
    'ρ': 'p', 'τ': 't', 'υ': 'u', 'χ': 'x',
    'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H', 'Ι': 'I', 'Κ': 'K',
    'Μ': 'M', 'Ν': 'N', 'Ο': 'O', 'Ρ': 'P', 'Τ': 'T', 'Υ': 'Y', 'Χ': 'X'
}

HOMOGLYPH_MAP = {**CYRILLIC_TO_LATIN, **GREEK_TO_LATIN}

# --- F2: Odd Whitespace Characters ---
ODD_WHITESPACE_MAP = {
    '\u00A0': 'NO-BREAK SPACE',
    '\u1680': 'OGHAM SPACE MARK',
    '\u2000': 'EN QUAD',
    '\u2001': 'EM QUAD',
    '\u2002': 'EN SPACE',
    '\u2003': 'EM SPACE',
    '\u2004': 'THREE-PER-EM SPACE',
    '\u2005': 'FOUR-PER-EM SPACE',
    '\u2006': 'SIX-PER-EM SPACE',
    '\u2007': 'FIGURE SPACE',
    '\u2008': 'PUNCTUATION SPACE',
    '\u2009': 'THIN SPACE',
    '\u200A': 'HAIR SPACE',
    '\u202F': 'NARROW NO-BREAK SPACE',
    '\u205F': 'MEDIUM MATHEMATICAL SPACE',
    '\u3000': 'IDEOGRAPHIC SPACE'
}

# --- F3: Zero-Width, Formatting, and Invisible Control Characters ---
INVISIBLE_CHAR_MAP = {
    '\u200B': 'ZERO WIDTH SPACE',
    '\u200C': 'ZERO WIDTH NON-JOINER',
    '\u200D': 'ZERO WIDTH JOINER',
    '\u200E': 'LEFT-TO-RIGHT MARK',
    '\u200F': 'RIGHT-TO-LEFT MARK',
    '\u202A': 'LEFT-TO-RIGHT EMBEDDING',
    '\u202B': 'RIGHT-TO-LEFT EMBEDDING',
    '\u202C': 'POP DIRECTIONAL FORMATTING',
    '\u202D': 'LEFT-TO-RIGHT OVERRIDE',
    '\u202E': 'RIGHT-TO-LEFT OVERRIDE',
    '\u2060': 'WORD JOINER',
    '\u2061': 'FUNCTION APPLICATION',
    '\u2062': 'INVISIBLE TIMES',
    '\u2063': 'INVISIBLE SEPARATOR',
    '\u2064': 'INVISIBLE PLUS',
    '\u2066': 'LEFT-TO-RIGHT ISOLATE',
    '\u2067': 'RIGHT-TO-LEFT ISOLATE',
    '\u2068': 'FIRST STRONG ISOLATE',
    '\u2069': 'POP DIRECTIONAL ISOLATE',
    '\uFEFF': 'ZERO WIDTH NO-BREAK SPACE',
    '\u00AD': 'SOFT HYPHEN'
}

# Unicode Script Ranges
TAMIL_RANGE = (0x0B80, 0x0BFF)
DEVANAGARI_RANGE = (0x0900, 0x097F)
ARABIC_RANGE = (0x0600, 0x06FF)

def is_in_range(char: str, char_range: Tuple[int, int]) -> bool:
    cp = ord(char)
    return char_range[0] <= cp <= char_range[1]

def is_tamil(char: str) -> bool:
    return is_in_range(char, TAMIL_RANGE)

def is_indic_or_arabic(char: str) -> bool:
    return (
        is_in_range(char, TAMIL_RANGE)
        or is_in_range(char, DEVANAGARI_RANGE)
        or is_in_range(char, ARABIC_RANGE)
    )

def is_printable_text(text: str, threshold: float = 0.80) -> bool:
    """Verifies that a string consists predominantly of printable characters and natural spacing."""
    if not text or len(text.strip()) == 0:
        return False
    printable = sum(1 for c in text if c.isprintable() or c in '\r\n\t')
    return (printable / len(text)) >= threshold

# --- Safety Sanitizer for Unicode ---
def sanitize_unicode(text: str) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Safely sanitizes lone surrogates or bad byte strings that could crash standard libraries.
    Replaces lone surrogates with standard U+FFFD replacement character and logs findings.
    """
    findings = []
    chars = []
    for idx, c in enumerate(text):
        cp = ord(c)
        if 0xD800 <= cp <= 0xDFFF:
            chars.append('\uFFFD')
            findings.append({
                "type": "malformed_unicode",
                "severity": "low",
                "span": {"start": idx, "end": idx + 1},
                "readable_evidence": f"Lone surrogate U+{cp:04X} safely replaced with U+FFFD",
                "confidence": 1.0
            })
        else:
            chars.append(c)
    return "".join(chars), findings

# --- F2: Homoglyph & Mixed Script Detection ---
def analyze_homoglyphs(text: str) -> Tuple[Optional[str], List[Dict[str, Any]]]:
    """
    Detects tokens that mix Latin characters with Cyrillic or Greek homoglyphs.
    Pure non-English words (e.g. pure Russian or pure Tamil) are NOT flagged as mixed script.
    Produces a derived representation where homoglyphs within mixed/latin words are resolved.
    """
    findings = []
    # Identify word tokens
    words = re.finditer(r'\b[\w\u0400-\u04FF\u0370-\u03FF]+\b', text)
    has_mixed = False
    resolved_chars = list(text)

    for m in words:
        word = m.group(0)
        has_latin = any(('a' <= c.lower() <= 'z') for c in word)
        has_cyrillic = any(('\u0400' <= c <= '\u04FF') for c in word)
        has_greek = any(('\u0370' <= c <= '\u03FF') for c in word)

        # Flag only when Latin is combined with Cyrillic or Greek inside the exact same word
        if has_latin and (has_cyrillic or has_greek):
            has_mixed = True
            mixed_script_names = []
            if has_cyrillic:
                mixed_script_names.append("Cyrillic")
            if has_greek:
                mixed_script_names.append("Greek")

            findings.append({
                "type": "mixed_script_homoglyph",
                "severity": "high",
                "span": {"start": m.start(), "end": m.end()},
                "readable_evidence": f"Mixed-script word '{word}' blends Latin with {'/'.join(mixed_script_names)} homoglyphs",
                "confidence": 0.95
            })

            # Replace homoglyphs in this word
            for idx in range(m.start(), m.end()):
                c = text[idx]
                if c in HOMOGLYPH_MAP:
                    resolved_chars[idx] = HOMOGLYPH_MAP[c]

    resolved_text = "".join(resolved_chars) if has_mixed else None
    return resolved_text, findings

# --- F2: Odd Whitespace Detection ---
def analyze_odd_whitespace(text: str) -> Tuple[Optional[str], List[Dict[str, Any]]]:
    findings = []
    normalized_chars = []
    has_odd_space = False

    for idx, c in enumerate(text):
        if c in ODD_WHITESPACE_MAP:
            has_odd_space = True
            normalized_chars.append(' ')
            findings.append({
                "type": "odd_whitespace",
                "severity": "low",
                "span": {"start": idx, "end": idx + 1},
                "readable_evidence": f"Non-standard whitespace U+{ord(c):04X} ({ODD_WHITESPACE_MAP[c]})",
                "confidence": 0.90
            })
        else:
            normalized_chars.append(c)

    normalized_text = "".join(normalized_chars) if has_odd_space else None
    return normalized_text, findings

# --- F2: Stray Combining Marks (Zalgo) ---
def analyze_combining_marks(text: str) -> Tuple[Optional[str], List[Dict[str, Any]]]:
    """
    Detects stray combining marks attached to Latin letters or excessive mark stacking.
    Legitimate Indic / Tamil / Arabic vowel signs are excluded.
    """
    findings = []
    clean_chars = []
    has_stray = False
    prev_char = ''

    for idx, c in enumerate(text):
        category = unicodedata.category(c)
        is_mark = category in ('Mn', 'Mc', 'Me')

        if is_mark:
            # Check if this mark is attached to a Latin/ASCII letter or stacked on another mark
            attached_to_latin = ('a' <= prev_char.lower() <= 'z') or ('0' <= prev_char <= '9')
            # Check if it's in legitimate native Indic or Arabic scripts
            is_legit_script = is_indic_or_arabic(c) or is_indic_or_arabic(prev_char)

            if attached_to_latin and not is_legit_script:
                has_stray = True
                findings.append({
                    "type": "stray_combining_marks",
                    "severity": "medium",
                    "span": {"start": idx, "end": idx + 1},
                    "readable_evidence": f"Stray combining mark U+{ord(c):04X} attached to Latin '{prev_char}'",
                    "confidence": 0.85
                })
                # Skip appending stray mark
                continue
        
        clean_chars.append(c)
        prev_char = c

    clean_text = "".join(clean_chars) if has_stray else None
    return clean_text, findings

# --- F3: Zero-Width & Invisible Characters ---
def analyze_invisible_characters(text: str) -> Tuple[Optional[str], Optional[str], List[Dict[str, Any]]]:
    """
    Detects zero-width, formatting, and invisible characters.
    Produces:
    - readable_evidence_form: e.g. "ig[U+200B]nore"
    - invisible_removed_text: text with invisible characters stripped
    - findings: list of findings with severity (high if splitting Latin words, info if legitimate Tamil/emoji)
    """
    findings = []
    readable_form_list = []
    clean_chars = []
    has_invisible = False

    for idx, c in enumerate(text):
        if c in INVISIBLE_CHAR_MAP:
            has_invisible = True
            char_hex = f"U+{ord(c):04X}"
            char_name = INVISIBLE_CHAR_MAP[c]
            readable_form_list.append(f"[{char_hex}]")

            # Check surrounding context: Tamil, Indic, or Emoji use is legitimate and informational only
            prev_c = text[idx - 1] if idx > 0 else ''
            next_c = text[idx + 1] if idx + 1 < len(text) else ''

            is_legit_context = (
                is_indic_or_arabic(prev_c) or is_indic_or_arabic(next_c)
                or (c in ('\u200D', '\u200C') and (unicodedata.category(prev_c) == 'So' or unicodedata.category(next_c) == 'So'))
            )

            # Check if splitting Latin characters
            splits_latin = ('a' <= prev_c.lower() <= 'z') and ('a' <= next_c.lower() <= 'z')

            severity = "info" if is_legit_context else ("high" if splits_latin else "medium")
            reason_suffix = " (legitimate script/emoji context)" if is_legit_context else " (splits Latin keyword)" if splits_latin else ""

            findings.append({
                "type": "invisible_characters",
                "severity": severity,
                "span": {"start": idx, "end": idx + 1},
                "readable_evidence": f"Invisible character {char_hex} ({char_name}){reason_suffix}",
                "confidence": 0.95
            })
        else:
            readable_form_list.append(c)
            clean_chars.append(c)

    if has_invisible:
        return "".join(clean_chars), "".join(readable_form_list), findings
    return None, None, []

# --- F4: Payload Decoders ---

def try_decode_base64(text: str) -> List[Tuple[str, str, int, int]]:
    """
    Detects base64 candidate strings and decodes them safely.
    Skips Data URIs for images.
    Returns list of tuples: (decoded_string, matched_candidate, start, end)
    """
    results = []
    # Match candidate base64 strings of length >= 16 (standard and urlsafe)
    # Must be bounded by non-alphanumeric or word boundaries
    pattern = r'(?<![A-Za-z0-9+/=])([A-Za-z0-9+/]{16,}={0,2}|[A-Za-z0-9-_]{16,}={0,2})(?![A-Za-z0-9+/=])'
    
    for m in re.finditer(pattern, text):
        candidate = m.group(1)
        # Avoid decoding image data-URIs or non-text markers
        context_window = text[max(0, m.start() - 30):m.start()].lower()
        if "data:image" in context_window:
            continue

        try:
            # Normalize padding if needed
            pad_len = (4 - len(candidate) % 4) % 4
            padded = candidate + ("=" * pad_len)
            
            # Try standard base64 or urlsafe base64
            decoded_bytes = None
            try:
                decoded_bytes = base64.b64decode(padded, validate=True)
            except Exception:
                decoded_bytes = base64.urlsafe_b64decode(padded)

            if decoded_bytes and len(decoded_bytes) >= 4:
                decoded_str = decoded_bytes.decode('utf-8', errors='replace')
                # Must be mostly printable text with at least some letters/whitespace
                if is_printable_text(decoded_str, threshold=0.75) and re.search(r'[a-zA-Z]{3,}', decoded_str):
                    results.append((decoded_str, candidate, m.start(), m.end()))
        except Exception:
            continue
    return results

def try_decode_url(text: str) -> Optional[Tuple[str, str]]:
    """Decodes URL percent-encoding if percent hex sequences are present."""
    if '%' in text and re.search(r'%[0-9a-fA-F]{2}', text):
        try:
            decoded = urllib.parse.unquote(text)
            if decoded != text and is_printable_text(decoded):
                return decoded, "url"
        except Exception:
            pass
    return None

def try_decode_html_entities(text: str) -> Optional[Tuple[str, str]]:
    """Decodes HTML entities (&quot;, &#105;, &#x69;)."""
    if re.search(r'&(?:[a-zA-Z]+|#[0-9]+|#x[0-9a-fA-F]+);', text):
        try:
            decoded = html.unescape(text)
            if decoded != text and is_printable_text(decoded):
                return decoded, "html_entity"
        except Exception:
            pass
    return None

def try_decode_unicode_escapes(text: str) -> Optional[Tuple[str, str]]:
    """Decodes \\uXXXX and \\U0000XXXX unicode escapes without executing code."""
    if re.search(r'(?:\\u[0-9a-fA-F]{4}){2,}|(?:\\U[0-9a-fA-F]{8}){1,}', text):
        try:
            # Safe replacement using regex
            def replace_u(match):
                hex_val = match.group(1)
                return chr(int(hex_val, 16))

            decoded = re.sub(r'\\u([0-9a-fA-F]{4})', replace_u, text)
            decoded = re.sub(r'\\U([0-9a-fA-F]{8})', replace_u, decoded)
            if decoded != text and is_printable_text(decoded):
                return decoded, "unicode_escape"
        except Exception:
            pass
    return None

def try_decode_hex(text: str) -> Optional[Tuple[str, str]]:
    """Decodes \\xHH sequences or space-separated hex bytes."""
    # Pattern 1: \x69\x67...
    m_hex = re.search(r'((?:\\x[0-9a-fA-F]{2}){4,})', text)
    if m_hex:
        try:
            hex_seq = m_hex.group(1).replace(r'\x', '')
            decoded_bytes = bytes.fromhex(hex_seq)
            decoded_str = decoded_bytes.decode('utf-8', errors='replace')
            if is_printable_text(decoded_str):
                replaced = text[:m_hex.start()] + decoded_str + text[m_hex.end():]
                return replaced, "hex"
        except Exception:
            pass

    # Pattern 2: Space-separated hex numbers e.g. "69 67 6e 6f 72 65"
    hex_seq_match = re.search(r'\b((?:[0-9a-fA-F]{2}\s+){4,}[0-9a-fA-F]{2})\b', text)
    if hex_seq_match:
        try:
            raw_seq = hex_seq_match.group(1)
            cleaned = re.sub(r'\s+', '', raw_seq)
            decoded_bytes = bytes.fromhex(cleaned)
            decoded_str = decoded_bytes.decode('utf-8', errors='replace')
            if is_printable_text(decoded_str) and len(decoded_str.strip()) >= 4:
                replaced = text[:hex_seq_match.start()] + decoded_str + text[hex_seq_match.end():]
                return replaced, "hex_spaced"
        except Exception:
            pass

    return None

# --- Main Obfuscation & Decoding Pipeline ---

def analyze_obfuscation(
    raw_text: str,
    max_input_size: Optional[int] = None,
    max_decode_depth: Optional[int] = None,
    max_decoded_size: Optional[int] = None,
    time_budget_ms: Optional[float] = None
) -> Dict[str, Any]:
    """
    Main obfuscation analysis function (Phase B).
    Evaluates raw text against F2 (Unicode), F3 (Invisible chars), and F4 (Decoded payloads).

    Returns:
    {
        "original_text": str,
        "derived_representations": List[Dict[str, Any]],
        "findings": List[Dict[str, Any]],
        "stages_skipped": List[str]
    }
    """
    t_start = time.perf_counter()

    # Apply configuration defaults
    limit_input = max_input_size or getattr(settings, "OBFUSCATION_MAX_INPUT_SIZE", 50000)
    limit_depth = max_decode_depth or getattr(settings, "OBFUSCATION_MAX_DECODE_DEPTH", 3)
    limit_decoded = max_decoded_size or getattr(settings, "OBFUSCATION_MAX_DECODED_SIZE", 100000)
    budget_ms = time_budget_ms or getattr(settings, "OBFUSCATION_TIME_BUDGET_MS", 250.0)

    stages_skipped: List[str] = []
    findings: List[Dict[str, Any]] = []
    derived_representations: List[Dict[str, Any]] = []
    seen_texts: Set[str] = set()

    if raw_text is None:
        raw_text = ""

    # Check input size limit
    if len(raw_text) > limit_input:
        stages_skipped.append("input_size_exceeded")
        return {
            "original_text": raw_text,
            "derived_representations": [],
            "findings": [{
                "type": "input_size_exceeded",
                "severity": "info",
                "span": None,
                "readable_evidence": f"Input size {len(raw_text)} exceeds maximum obfuscation threshold {limit_input}",
                "confidence": 1.0
            }],
            "stages_skipped": stages_skipped
        }

    # Step 1: Sanitize lone surrogates or malformed Unicode
    sanitized_text, unicode_sanity_findings = sanitize_unicode(raw_text)
    findings.extend(unicode_sanity_findings)
    seen_texts.add(sanitized_text)

    # Step 2 (F2): NFC vs NFKC Normalization Check
    nfc = unicodedata.normalize("NFC", sanitized_text)
    nfkc = unicodedata.normalize("NFKC", sanitized_text)
    if nfc != nfkc:
        findings.append({
            "type": "unicode_normalization_drift",
            "severity": "medium",
            "span": None,
            "readable_evidence": "NFKC normalization modified character presentation (e.g. fullwidth/circled compatibility characters)",
            "confidence": 0.85
        })
        derived_representations.append({
            "label": "nfkc",
            "text": nfkc,
            "depth": 0,
            "encoding_chain": ["nfkc"],
            "findings_count": 1
        })
        seen_texts.add(nfkc)

    # Step 3 (F2): Homoglyphs & Mixed Script
    homoglyphs_resolved, homoglyph_findings = analyze_homoglyphs(sanitized_text)
    findings.extend(homoglyph_findings)
    if homoglyphs_resolved and homoglyphs_resolved not in seen_texts:
        derived_representations.append({
            "label": "homoglyphs_resolved",
            "text": homoglyphs_resolved,
            "depth": 0,
            "encoding_chain": ["homoglyphs_resolved"],
            "findings_count": len(homoglyph_findings)
        })
        seen_texts.add(homoglyphs_resolved)

    # Step 4 (F2): Odd Whitespace
    odd_ws_normalized, odd_ws_findings = analyze_odd_whitespace(sanitized_text)
    findings.extend(odd_ws_findings)
    if odd_ws_normalized:
        derived_representations.append({
            "label": "odd_whitespace_normalized",
            "text": odd_ws_normalized,
            "depth": 0,
            "encoding_chain": ["odd_whitespace"],
            "findings_count": len(odd_ws_findings)
        })
        seen_texts.add(odd_ws_normalized)

    # Step 5 (F2): Stray Combining Marks (Zalgo)
    zalgo_removed, zalgo_findings = analyze_combining_marks(sanitized_text)
    findings.extend(zalgo_findings)
    if zalgo_removed and zalgo_removed not in seen_texts:
        derived_representations.append({
            "label": "combining_marks_removed",
            "text": zalgo_removed,
            "depth": 0,
            "encoding_chain": ["combining_marks_removed"],
            "findings_count": len(zalgo_findings)
        })
        seen_texts.add(zalgo_removed)

    # Step 6 (F3): Zero-Width and Invisible Characters
    invis_removed, readable_form, invis_findings = analyze_invisible_characters(sanitized_text)
    findings.extend(invis_findings)
    if invis_removed and invis_removed not in seen_texts:
        derived_representations.append({
            "label": "invisible_removed",
            "text": invis_removed,
            "depth": 0,
            "encoding_chain": ["invisible_removed"],
            "findings_count": len(invis_findings)
        })
        seen_texts.add(invis_removed)

    # Step 7 (F4): Recursive Candidate Decoding (Base64, URL, HTML Entity, Unicode Escape, Hex)
    # Queue: (current_text, current_depth, encoding_chain)
    decode_queue: List[Tuple[str, int, List[str]]] = [(sanitized_text, 0, [])]
    
    # Also seed with invisible_removed or nfkc if available
    if invis_removed:
        decode_queue.append((invis_removed, 0, ["invisible_removed"]))

    while decode_queue:
        # Check time budget
        elapsed_ms = (time.perf_counter() - t_start) * 1000.0
        if elapsed_ms > budget_ms:
            stages_skipped.append("time_budget_exceeded")
            break

        current_str, current_depth, chain = decode_queue.pop(0)

        if current_depth >= limit_depth:
            if "depth_limit_reached" not in stages_skipped:
                stages_skipped.append("depth_limit_reached")
            continue

        next_depth = current_depth + 1

        # 7a: Base64 candidate decoding
        b64_results = try_decode_base64(current_str)
        for decoded_b64, cand, c_start, c_end in b64_results:
            if len(decoded_b64) > limit_decoded:
                if "decoded_size_exceeded" not in stages_skipped:
                    stages_skipped.append("decoded_size_exceeded")
                continue

            findings.append({
                "type": "encoded_payload",
                "severity": "medium",
                "span": {"start": c_start, "end": c_end},
                "readable_evidence": f"Decoded Base64 layer ({len(decoded_b64)} chars): '{decoded_b64[:60]}...'",
                "confidence": 0.95
            })

            new_chain = chain + ["base64"]
            rep_label = f"decoded_{'_'.join(new_chain)}"
            if decoded_b64 not in seen_texts:
                seen_texts.add(decoded_b64)
                derived_representations.append({
                    "label": rep_label,
                    "text": decoded_b64,
                    "depth": next_depth,
                    "encoding_chain": new_chain,
                    "findings_count": 1
                })
                decode_queue.append((decoded_b64, next_depth, new_chain))

        # 7b: URL Percent-Encoding
        url_res = try_decode_url(current_str)
        if url_res:
            decoded_url, enc_type = url_res
            if len(decoded_url) <= limit_decoded and decoded_url not in seen_texts:
                findings.append({
                    "type": "encoded_payload",
                    "severity": "low",
                    "span": None,
                    "readable_evidence": f"Decoded URL percent-encoding: '{decoded_url[:60]}...'",
                    "confidence": 0.90
                })
                new_chain = chain + ["url"]
                rep_label = f"decoded_{'_'.join(new_chain)}"
                seen_texts.add(decoded_url)
                derived_representations.append({
                    "label": rep_label,
                    "text": decoded_url,
                    "depth": next_depth,
                    "encoding_chain": new_chain,
                    "findings_count": 1
                })
                decode_queue.append((decoded_url, next_depth, new_chain))

        # 7c: HTML Entities
        html_res = try_decode_html_entities(current_str)
        if html_res:
            decoded_html, enc_type = html_res
            if len(decoded_html) <= limit_decoded and decoded_html not in seen_texts:
                findings.append({
                    "type": "encoded_payload",
                    "severity": "low",
                    "span": None,
                    "readable_evidence": f"Decoded HTML entities: '{decoded_html[:60]}...'",
                    "confidence": 0.90
                })
                new_chain = chain + ["html_entity"]
                rep_label = f"decoded_{'_'.join(new_chain)}"
                seen_texts.add(decoded_html)
                derived_representations.append({
                    "label": rep_label,
                    "text": decoded_html,
                    "depth": next_depth,
                    "encoding_chain": new_chain,
                    "findings_count": 1
                })
                decode_queue.append((decoded_html, next_depth, new_chain))

        # 7d: Unicode Escapes
        u_res = try_decode_unicode_escapes(current_str)
        if u_res:
            decoded_u, enc_type = u_res
            if len(decoded_u) <= limit_decoded and decoded_u not in seen_texts:
                findings.append({
                    "type": "encoded_payload",
                    "severity": "medium",
                    "span": None,
                    "readable_evidence": f"Decoded \\uXXXX unicode escapes: '{decoded_u[:60]}...'",
                    "confidence": 0.95
                })
                new_chain = chain + ["unicode_escape"]
                rep_label = f"decoded_{'_'.join(new_chain)}"
                seen_texts.add(decoded_u)
                derived_representations.append({
                    "label": rep_label,
                    "text": decoded_u,
                    "depth": next_depth,
                    "encoding_chain": new_chain,
                    "findings_count": 1
                })
                decode_queue.append((decoded_u, next_depth, new_chain))

        # 7e: Hex Sequences
        hex_res = try_decode_hex(current_str)
        if hex_res:
            decoded_hex, enc_type = hex_res
            if len(decoded_hex) <= limit_decoded and decoded_hex not in seen_texts:
                findings.append({
                    "type": "encoded_payload",
                    "severity": "medium",
                    "span": None,
                    "readable_evidence": f"Decoded hex sequence: '{decoded_hex[:60]}...'",
                    "confidence": 0.95
                })
                new_chain = chain + ["hex"]
                rep_label = f"decoded_{'_'.join(new_chain)}"
                seen_texts.add(decoded_hex)
                derived_representations.append({
                    "label": rep_label,
                    "text": decoded_hex,
                    "depth": next_depth,
                    "encoding_chain": new_chain,
                    "findings_count": 1
                })
                decode_queue.append((decoded_hex, next_depth, new_chain))

    return {
        "original_text": raw_text,
        "derived_representations": derived_representations,
        "findings": findings,
        "stages_skipped": stages_skipped
    }
