"""
Risk scoring module for AI Prompt Injection Detection.
Transforms primary classifier probabilities into explainable 0-100 risk scores
with bounded, rule-based evidence adjustments and conservative uncertainty handling.
"""
from typing import Dict, List, Any, Optional

DEFAULT_THRESHOLDS = {
    "low_max": 45.0,
    "medium_max": 60.0,
    "high_max": 79.0,
    "critical_max": 100.0
}

def compute_risk_score(
    primary_malicious_prob: float,
    features: Dict[str, float],
    has_spans: bool,
    model_disagreement: bool = False,
    thresholds: Optional[Dict[str, float]] = None,
    is_validated: bool = False
) -> Dict[str, Any]:
    """
    Computes explainable risk score (0-100), category, classification, and recommended action.
    Every adjustment is logged with exact point diff and rationale.
    """
    thresh = thresholds or DEFAULT_THRESHOLDS
    base_score = max(0.0, min(100.0, primary_malicious_prob * 100.0))
    current_score = base_score
    adjustments: List[Dict[str, Any]] = []

    # 1. Pattern-based positive adjustments (bounded increases)
    if features.get("combo_override_and_disclosure", 0.0) > 0.5:
        adj = 20.0
        current_score += adj
        adjustments.append({
            "rule": "override_and_disclosure_combination",
            "delta": adj,
            "reason": "Simultaneous instruction override and secret disclosure request detected."
        })
    elif features.get("has_instruction_override", 0.0) > 0.5:
        adj = 15.0
        current_score += adj
        adjustments.append({
            "rule": "instruction_override_detected",
            "delta": adj,
            "reason": "Explicit instruction override phrase detected (e.g. 'ignore previous instructions')."
        })
    elif features.get("has_protected_disclosure", 0.0) > 0.5:
        adj = 10.0
        current_score += adj
        adjustments.append({
            "rule": "protected_disclosure_detected",
            "delta": adj,
            "reason": "Request attempting to extract system prompt, developer rules, or secrets."
        })

    if features.get("has_roleplay_jailbreak", 0.0) > 0.5:
        adj = 15.0
        current_score += adj
        adjustments.append({
            "rule": "roleplay_jailbreak_detected",
            "delta": adj,
            "reason": "Persona hijacking / jailbreak indicator detected (e.g. DAN, developer mode)."
        })

    if features.get("has_delimiter_format", 0.0) > 0.5:
        adj = 12.0
        current_score += adj
        adjustments.append({
            "rule": "delimiter_formatting_trick",
            "delta": adj,
            "reason": "Faux system delimiter or structured token injection detected."
        })

    if features.get("has_encoded_obfuscation", 0.0) > 0.5:
        adj = 10.0
        current_score += adj
        adjustments.append({
            "rule": "encoded_payload_indicator",
            "delta": adj,
            "reason": "Encoded command or obfuscated payload structure detected."
        })

    # 2. Educational & Academic Context Mitigation (bounded reduction)
    if features.get("is_academic_context", 0.0) > 0.5:
        # If there is academic context and no explicit override command, strongly reduce risk
        if features.get("has_instruction_override", 0.0) < 0.5 and features.get("has_roleplay_jailbreak", 0.0) < 0.5:
            adj = -30.0
            current_score += adj
            adjustments.append({
                "rule": "academic_security_context",
                "delta": adj,
                "reason": "Legitimate academic or educational security framing identified without active override payload."
            })
        else:
            # Academic phrasing combined with actual override syntax
            adj = -10.0
            current_score += adj
            adjustments.append({
                "rule": "partial_academic_mitigation",
                "delta": adj,
                "reason": "Academic discussion phrases noted, but active injection syntax remains present."
            })

    # 3. Clean syntax pattern adjustment (no adversarial indicators present)
    if (
        not has_spans
        and features.get("has_instruction_override", 0.0) < 0.5
        and features.get("has_protected_disclosure", 0.0) < 0.5
        and features.get("has_roleplay_jailbreak", 0.0) < 0.5
        and features.get("has_delimiter_format", 0.0) < 0.5
        and features.get("has_encoded_obfuscation", 0.0) < 0.5
    ):
        adj = -10.0
        current_score += adj
        adjustments.append({
            "rule": "no_adversarial_patterns_detected",
            "delta": adj,
            "reason": "Clean natural language structure with zero matched adversarial injection indicators."
        })

    # Clamp final score
    final_score = round(max(0.0, min(100.0, current_score)), 1)

    # 3. Category Assignment
    if final_score <= thresh.get("low_max", 29.0):
        category = "Low"
        classification = "Safe"
        recommended_action = "Allow: Input poses negligible prompt injection risk."
    elif final_score <= thresh.get("medium_max", 59.0):
        category = "Medium"
        classification = "Suspicious"
        recommended_action = "Allow with review: Moderate injection indicators present; flag for logging."
    elif final_score <= thresh.get("high_max", 79.0):
        category = "High"
        classification = "Malicious"
        recommended_action = "Block: High probability of prompt injection. Require human review."
    else:
        category = "Critical"
        classification = "Malicious"
        recommended_action = "Block and log: Severe prompt injection exploit detected. Terminate request."

    # 4. Conservative Uncertainty Handling
    uncertainty_note = None
    # If models disagree significantly or score is near boundary, err on conservative side (Suspicious)
    if model_disagreement and classification == "Malicious":
        classification = "Suspicious"
        category = "Medium"
        recommended_action = "Allow with review: Classifiers exhibited divergence; classified conservatively as Suspicious."
        uncertainty_note = "Model agreement check failed (high divergence across algorithms). Treated conservatively as Suspicious."
    elif features.get("is_academic_context", 0.0) > 0.5 and classification == "Malicious":
        # Academic discussion must never be auto-classified as Malicious
        classification = "Suspicious"
        category = "Medium"
        recommended_action = "Allow with review: Academic security terminology detected. Reviewed as Suspicious rather than Malicious."
        uncertainty_note = "Contains educational/academic security terminology. Downgraded from Malicious to prevent false block."

    return {
        "base_score": round(base_score, 1),
        "risk_score": final_score,
        "risk_category": category,
        "classification": classification,
        "risk_score_type": "validated" if is_validated else "heuristic",
        "adjustments": adjustments,
        "recommended_action": recommended_action,
        "uncertainty_note": uncertainty_note
    }
