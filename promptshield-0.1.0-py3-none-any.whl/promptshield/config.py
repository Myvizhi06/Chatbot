"""
Application Configuration — loaded from environment variables with sensible defaults.
When installed as a package, DATABASE_PATH defaults to a platformdirs user-data directory
so it never tries to write next to the installed wheel. Override via PROMPTSHIELD_DATA_DIR
or DATABASE_PATH env vars.
"""
import os
from pathlib import Path
from typing import List

def _default_db_path() -> str:
    """
    Resolve database path:
      1. If DATABASE_PATH env var is set, use it directly.
      2. If PROMPTSHIELD_DATA_DIR is set, put app_data.db there.
      3. Otherwise use platformdirs user_data_dir for XDG/Windows compatibility.
    Falls back to cwd if platformdirs is not installed (dev mode).
    """
    if os.environ.get("DATABASE_PATH"):
        return os.environ["DATABASE_PATH"]
    data_dir = os.environ.get("PROMPTSHIELD_DATA_DIR")
    if not data_dir:
        try:
            from platformdirs import user_data_dir
            data_dir = user_data_dir("promptshield", "promptshield")
        except ImportError:
            data_dir = os.getcwd()
    Path(data_dir).mkdir(parents=True, exist_ok=True)
    return str(Path(data_dir) / "app_data.db")


class Settings:
    APP_NAME: str = "AI Prompt Injection Detection & Protection System"
    VERSION: str = "0.1.0"
    DEBUG: bool = os.environ.get("DEBUG", "false").lower() == "true"

    # Server bindings
    HOST: str = os.environ.get("APP_HOST", "127.0.0.1")
    PORT: int = int(os.environ.get("APP_PORT", 8000))

    # CORS origins
    CORS_ORIGINS: List[str] = [
        origin.strip()
        for origin in os.environ.get(
            "CORS_ORIGINS",
            "http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000"
        ).split(",")
        if origin.strip()
    ]

    # Database — resolved lazily so env vars set after import still apply
    @property
    def DATABASE_PATH(self) -> str:  # type: ignore[override]
        return _default_db_path()

    STORE_CONTENT_PREVIEW: bool = os.environ.get("STORE_CONTENT_PREVIEW", "false").lower() == "true"

    # Input constraints
    MAX_INPUT_LENGTH: int = int(os.environ.get("MAX_INPUT_LENGTH", 20000))
    MAX_UPLOAD_SIZE_MB: int = int(os.environ.get("MAX_UPLOAD_SIZE_MB", 5))
    MAX_DOCUMENT_EXTRACT_CHARS: int = int(os.environ.get("MAX_DOCUMENT_EXTRACT_CHARS", 100000))

    # Algorithm D (Optional Transformer)
    TRANSFORMER_ENABLED: bool = os.environ.get("TRANSFORMER_ENABLED", "false").lower() == "true"
    TRANSFORMER_MODEL_ID: str = os.environ.get(
        "TRANSFORMER_MODEL_ID",
        "protectai/deberta-v3-base-prompt-injection-v2"
    )

    # Optional External AI Rewriter
    EXTERNAL_AI_ENABLED: bool = os.environ.get("EXTERNAL_AI_ENABLED", "false").lower() == "true"
    EXTERNAL_AI_API_KEY: str = os.environ.get("EXTERNAL_AI_API_KEY", "")

    # Obfuscation & Decoding Pipeline Limits (Phase B)
    OBFUSCATION_MAX_INPUT_SIZE: int = int(os.environ.get("OBFUSCATION_MAX_INPUT_SIZE", 50000))
    OBFUSCATION_MAX_DECODE_DEPTH: int = int(os.environ.get("OBFUSCATION_MAX_DECODE_DEPTH", 3))
    OBFUSCATION_MAX_DECODED_SIZE: int = int(os.environ.get("OBFUSCATION_MAX_DECODED_SIZE", 100000))
    OBFUSCATION_TIME_BUDGET_MS: float = float(os.environ.get("OBFUSCATION_TIME_BUDGET_MS", 250.0))


settings = Settings()
