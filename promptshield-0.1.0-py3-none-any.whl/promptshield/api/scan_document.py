"""
API endpoint for document scanning: POST /api/scan-document
"""
from fastapi import APIRouter, UploadFile, File, HTTPException
from promptshield.schemas import ScanDocumentResponse
from promptshield.document_scanner import scan_document_content
from promptshield.database import insert_scan

router = APIRouter()

@router.post("/scan-document", response_model=ScanDocumentResponse)
async def scan_document_endpoint(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Uploaded file must have a valid filename.")

    try:
        content_bytes = await file.read()
    except Exception:
        raise HTTPException(status_code=400, detail="Failed to read uploaded file payload.")

    # Call scanner logic
    scan_res = scan_document_content(file.filename, content_bytes)

    # Record scan in SQLite
    scan_id = insert_scan(
        input_type="document",
        raw_text=scan_res["extracted_text"],
        classification=scan_res["document_classification"],
        risk_score=scan_res["document_risk_score"],
        risk_category=scan_res["document_category"],
        detection_summary=scan_res["detection_summary"],
        indicators=[
            ind for p in scan_res["passages"] for ind in p["indicators"]
        ],
        model_version=scan_res["model_version"],
        primary_model="Pipeline Ensemble",
        model_results=[],
        filename=file.filename
    )

    scan_res["scan_id"] = scan_id
    return scan_res
