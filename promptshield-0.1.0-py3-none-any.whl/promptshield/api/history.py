"""
API endpoints for audit history:
GET /api/history
GET /api/history/{id}
DELETE /api/history
"""
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Query
from promptshield.schemas import HistoryResponse, ScanRecord, DeleteHistoryResponse
from promptshield.database import get_scans, get_scan_by_id, delete_scans

router = APIRouter()

@router.get("/history", response_model=HistoryResponse)
async def list_history_endpoint(
    q: Optional[str] = Query(None, description="Search term across filename or detection summary"),
    classification: Optional[str] = Query(None, description="Filter by classification (Safe, Suspicious, Malicious)"),
    input_type: Optional[str] = Query(None, description="Filter by input type (prompt, document)"),
    date_from: Optional[str] = Query(None, alias="from", description="ISO start date"),
    date_to: Optional[str] = Query(None, alias="to", description="ISO end date"),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0)
):
    rows, total = get_scans(
        q=q,
        classification=classification,
        input_type=input_type,
        date_from=date_from,
        date_to=date_to,
        limit=limit,
        offset=offset
    )
    items = [ScanRecord(**r) for r in rows]
    return HistoryResponse(total=total, limit=limit, offset=offset, items=items)

@router.get("/history/{scan_id}", response_model=ScanRecord)
async def get_scan_detail_endpoint(scan_id: str):
    record = get_scan_by_id(scan_id)
    if not record:
        raise HTTPException(status_code=404, detail="Scan record not found.")
    return ScanRecord(**record)

@router.delete("/history", response_model=DeleteHistoryResponse)
async def delete_history_endpoint(
    ids: Optional[str] = Query(None, description="Comma-separated scan UUIDs to delete"),
    before: Optional[str] = Query(None, description="Delete records created before this ISO date")
):
    id_list: Optional[List[str]] = None
    if ids:
        id_list = [i.strip() for i in ids.split(",") if i.strip()]

    deleted_count = delete_scans(scan_ids=id_list, before_date=before)
    if id_list:
        msg = f"Successfully deleted {deleted_count} scan record(s)."
    elif before:
        msg = f"Successfully deleted {deleted_count} scan record(s) older than {before}."
    else:
        msg = f"Successfully purged all {deleted_count} scan record(s)."

    return DeleteHistoryResponse(deleted_count=deleted_count, message=msg)
