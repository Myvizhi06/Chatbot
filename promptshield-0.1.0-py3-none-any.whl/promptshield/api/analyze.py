"""
API endpoint for single prompt analysis: POST /api/analyze
"""
from fastapi import APIRouter, HTTPException, Request
from promptshield.config import settings
from promptshield.schemas import AnalyzeRequest, AnalyzeResponse
from promptshield.ml.inference import get_pipeline
from promptshield.database import insert_scan

router = APIRouter()

@router.post("/analyze", response_model=AnalyzeResponse)
async def analyze_prompt_endpoint(payload: AnalyzeRequest, request: Request):
    text = payload.text.strip()
    if not text:
        raise HTTPException(
            status_code=422,
            detail="Prompt text cannot be empty or solely whitespace."
        )

    if len(payload.text) > settings.MAX_INPUT_LENGTH:
        raise HTTPException(
            status_code=422,
            detail=f"Prompt text exceeds maximum length limit of {settings.MAX_INPUT_LENGTH} characters."
        )

    pipeline = get_pipeline()
    try:
        result = pipeline.analyze_prompt(payload.text, max_length=settings.MAX_INPUT_LENGTH)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal analysis error processing prompt.")

    # Save to SQLite scans table
    scan_id = insert_scan(
        input_type="prompt",
        raw_text=payload.text,
        classification=result["classification"],
        risk_score=result["risk_score"],
        risk_category=result["risk_category"],
        detection_summary=result["detection_summary"],
        indicators=result["indicators"],
        model_version=result["model_version"],
        primary_model=result["primary_model"],
        model_results=result["model_results"],
        filename=None
    )

    response_data = {
        "scan_id": scan_id,
        "classification": result["classification"],
        "risk_score": result["risk_score"],
        "risk_category": result["risk_category"],
        "risk_score_type": result["risk_score_type"],
        "detection_summary": result["detection_summary"],
        "indicators": result["indicators"],
        "model_results": result["model_results"],
        "primary_model": result["primary_model"],
        "explanation": result["explanation"],
        "recommended_action": result["recommended_action"],
        "safe_suggestion": result["safe_suggestion"],
        "model_version": result["model_version"],
        "limitations": result["limitations"]
    }

    return response_data
