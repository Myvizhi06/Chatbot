"""
API endpoint for security dashboard metrics: GET /api/dashboard
All statistics computed dynamically from real database records.
"""
from fastapi import APIRouter
from promptshield.schemas import DashboardResponse, ScanRecord
from promptshield.database import get_dashboard_metrics
from promptshield.ml.inference import get_pipeline

router = APIRouter()

@router.get("/dashboard", response_model=DashboardResponse)
async def get_dashboard_endpoint():
    metrics = get_dashboard_metrics()
    pipeline = get_pipeline()

    # Model availability status
    models_available = [
        {
            "name": "LogisticRegression (Algorithm A)",
            "type": "TF-IDF N-gram Linear",
            "status": "loaded" if pipeline.model_lr is not None else "unavailable",
            "is_primary": pipeline.primary_model_name == "LogisticRegression"
        },
        {
            "name": "MultinomialNB (Algorithm B)",
            "type": "Probabilistic Naive Bayes",
            "status": "loaded" if pipeline.model_nb is not None else "unavailable",
            "is_primary": pipeline.primary_model_name == "NaiveBayes"
        },
        {
            "name": "RandomForest (Algorithm C)",
            "type": "Heuristic Feature Trees",
            "status": "loaded" if pipeline.model_rf is not None else "unavailable",
            "is_primary": pipeline.primary_model_name == "RandomForest"
        },
        {
            "name": "DeBERTa Classifier (Algorithm D)",
            "type": "Deep Transformer",
            "status": pipeline.transformer_status,
            "is_primary": False,
            "reason": pipeline.transformer_reason
        }
    ]

    recent_records = [ScanRecord(**r) for r in metrics.get("recent_scans", [])]

    return DashboardResponse(
        empty=metrics["empty"],
        total_scans=metrics["total_scans"],
        safe_count=metrics["safe_count"],
        suspicious_count=metrics["suspicious_count"],
        malicious_count=metrics["malicious_count"],
        classification_counts=metrics["classification_counts"],
        category_counts=metrics["category_counts"],
        score_histogram=metrics["score_histogram"],
        daily_scans=metrics["daily_scans"],
        recent_scans=recent_records,
        models_available=models_available
    )
