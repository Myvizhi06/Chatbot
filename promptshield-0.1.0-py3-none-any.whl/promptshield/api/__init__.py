"""
API Routers package.
"""
from fastapi import APIRouter
from promptshield.api.analyze import router as analyze_router
from promptshield.api.scan_document import router as scan_document_router
from promptshield.api.history import router as history_router
from promptshield.api.dashboard import router as dashboard_router
from promptshield.api.model_info import router as model_info_router
from promptshield.api.health import router as health_router

api_router = APIRouter(prefix="/api")
api_router.include_router(analyze_router, tags=["Analysis"])
api_router.include_router(scan_document_router, tags=["Document Scanner"])
api_router.include_router(history_router, tags=["Scan History"])
api_router.include_router(dashboard_router, tags=["Dashboard"])
api_router.include_router(model_info_router, tags=["Model Info"])
api_router.include_router(health_router, tags=["Health"])
