"""
API endpoint for service health check: GET /api/health
"""
from datetime import datetime, timezone
from fastapi import APIRouter
from promptshield.config import settings
from promptshield.schemas import HealthResponse

router = APIRouter()

@router.get("/health", response_model=HealthResponse)
async def get_health_endpoint():
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now(timezone.utc).isoformat(),
        version=settings.VERSION
    )
