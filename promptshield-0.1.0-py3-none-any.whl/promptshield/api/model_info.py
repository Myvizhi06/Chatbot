"""
API endpoint for model info, evaluation metrics, and dataset provenance: GET /api/model-info
"""
from fastapi import APIRouter
from promptshield.config import settings
from promptshield.schemas import ModelInfoResponse
from promptshield.ml.inference import get_pipeline

router = APIRouter()

@router.get("/model-info", response_model=ModelInfoResponse)
async def get_model_info_endpoint():
    pipeline = get_pipeline()
    meta = pipeline.metadata or {}
    eval_data = pipeline.evaluation or {}

    is_demo = meta.get("is_demo_dataset", True)
    demo_msg = None
    if is_demo:
        demo_msg = (
            "Notice: Trained on demonstration dataset (data/sample/dataset.csv). "
            "Designed for demonstration and local offline benchmarking, not production safety coverage."
        )

    return ModelInfoResponse(
        primary_model=pipeline.primary_model_name,
        model_version=meta.get("model_version", "v1.0.0_unversioned"),
        is_demo_dataset=is_demo,
        demo_banner_message=demo_msg,
        dataset_name=meta.get("dataset_name", "dataset.csv"),
        dataset_rows=meta.get("dataset_rows", 240),
        dataset_hash=meta.get("dataset_hash", "local_curated"),
        dataset_license="Apache 2.0 (Deepset / Curated Demonstration)",
        dataset_url="https://huggingface.co/datasets/deepset/prompt-injections",
        thresholds=pipeline.thresholds,
        thresholds_status=meta.get("thresholds_status", "heuristic"),
        selection_rationale=meta.get("selection_rationale", "Selected by highest validation Malicious F1 score with recall as tie-breaker."),
        evaluation_available=eval_data.get("evaluation_available", False),
        evaluation=eval_data if eval_data.get("evaluation_available") else None,
        transformer_status=pipeline.transformer_status,
        transformer_model_id=settings.TRANSFORMER_MODEL_ID,
        transformer_reason=pipeline.transformer_reason
    )
