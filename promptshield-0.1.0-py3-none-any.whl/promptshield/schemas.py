"""
Pydantic v2 schemas and data validation models for API contracts.
"""
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field, ConfigDict

# --- Prompt Analysis Schemas ---
class AnalyzeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    text: str = Field(..., min_length=1, description="Prompt text to analyze")

class IndicatorSpan(BaseModel):
    category: str
    text: str
    start: int
    end: int
    revealed_by: Optional[str] = None

class ObfuscationFinding(BaseModel):
    type: str
    severity: str
    span: Optional[Dict[str, int]] = None
    readable_evidence: str
    confidence: float

class DerivedRepresentation(BaseModel):
    label: str
    text: str
    depth: int = 0
    encoding_chain: List[str] = []
    findings_count: int = 0

class ModelResult(BaseModel):
    model: str
    status: str
    label: Optional[str] = None
    malicious_probability: Optional[float] = None
    inference_ms: Optional[float] = None
    reason: Optional[str] = None

class RewriteChange(BaseModel):
    type: str
    matched_text: str
    reason: str

class SafeSuggestion(BaseModel):
    text: str
    is_safe_already: bool
    has_content: bool
    changes: List[RewriteChange] = []
    disclaimer: str

class AnalyzeResponse(BaseModel):
    scan_id: str
    classification: str
    risk_score: float
    risk_category: str
    risk_score_type: str
    detection_summary: str
    indicators: List[IndicatorSpan]
    model_results: List[ModelResult]
    primary_model: str
    explanation: str
    recommended_action: str
    safe_suggestion: SafeSuggestion
    model_version: str
    limitations: str
    obfuscation_findings: Optional[List[ObfuscationFinding]] = None
    representations_analyzed: Optional[List[DerivedRepresentation]] = None
    stages_skipped: Optional[List[str]] = None

# --- Document Scanner Schemas ---
class MicroTextFinding(BaseModel):
    page: int
    font_size: float
    text: str
    classification: str
    risk_score: float
    is_injection: bool = False

class PassageResult(BaseModel):
    index: int
    start: int
    end: int
    text: str
    risk_score: float
    classification: str
    indicators: List[IndicatorSpan]

class ScanDocumentResponse(BaseModel):
    scan_id: str
    filename: str
    file_size_bytes: int
    total_passages: int
    flagged_passages_count: int
    document_risk_score: float
    document_classification: str
    document_category: str
    detection_summary: str
    passages: List[PassageResult]
    extracted_text: str
    truncated: bool
    notices: List[str]
    model_version: str
    limitations: str
    micro_text_findings: Optional[List[MicroTextFinding]] = None

# --- History & Scans Schemas ---
class ScanRecord(BaseModel):
    id: str
    created_at: str
    input_type: str
    filename: Optional[str] = None
    input_length: int
    classification: str
    risk_score: float
    risk_category: str
    detection_summary: str
    indicators_json: Optional[str] = None
    model_version: str
    primary_model: str
    model_results_json: Optional[str] = None
    content_preview: Optional[str] = None
    content_sha256: str

class HistoryResponse(BaseModel):
    total: int
    limit: int
    offset: int
    items: List[ScanRecord]

class DeleteHistoryResponse(BaseModel):
    deleted_count: int
    message: str

# --- Dashboard Schemas ---
class HistogramBucket(BaseModel):
    range_label: str
    count: int

class DailyCount(BaseModel):
    date: str
    count: int

class DashboardResponse(BaseModel):
    empty: bool
    total_scans: int
    safe_count: int
    suspicious_count: int
    malicious_count: int
    classification_counts: Dict[str, int]
    category_counts: Dict[str, int]
    score_histogram: List[HistogramBucket]
    daily_scans: List[DailyCount]
    recent_scans: List[ScanRecord]
    models_available: List[Dict[str, Any]]

# --- Model Info Schemas ---
class ModelInfoResponse(BaseModel):
    primary_model: str
    model_version: str
    is_demo_dataset: bool
    demo_banner_message: Optional[str] = None
    dataset_name: str
    dataset_rows: int
    dataset_hash: str
    dataset_license: str
    dataset_url: str
    thresholds: Dict[str, float]
    thresholds_status: str
    selection_rationale: str
    evaluation_available: bool
    evaluation: Optional[Dict[str, Any]] = None
    transformer_status: str
    transformer_model_id: str
    transformer_reason: Optional[str] = None

# --- Health Schema ---
class HealthResponse(BaseModel):
    status: str
    timestamp: str
    version: str
