"""
Document scanner module for PDF and TXT files.
Extracts text page-by-page, partitions into overlapping passages,
evaluates localized injection threats, and aggregates document-level risk scores.
Handles corrupted, encrypted, empty, and malformed files safely.
"""
import io
import os
from typing import Dict, Any, List, Tuple
from fastapi import HTTPException
from pypdf import PdfReader
from pypdf.errors import PdfReadError, FileNotDecryptedError

from promptshield.config import settings
from promptshield.ml.inference import get_pipeline

LIMITATIONS_NOTICE = (
    "Document scanning is probabilistic. Attacks contained in rasterized images, OCR-only content, "
    "hidden white-on-white text, non-standard font encodings, or unparsed attachments may be missed. "
    "Always exercise caution with untrusted documents."
)

def validate_file_metadata(filename: str, file_bytes: bytes, max_mb: int = 5):
    """
    Validates file extension, size, and header magic bytes.
    """
    if not filename:
        raise HTTPException(status_code=400, detail="Filename cannot be empty")

    ext = os.path.splitext(filename)[1].lower()
    if ext not in [".pdf", ".txt"]:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{ext}'. Only .pdf and .txt files are supported."
        )

    size_bytes = len(file_bytes)
    if size_bytes == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty (0 bytes).")

    max_bytes = max_mb * 1024 * 1024
    if size_bytes > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"File size exceeds maximum permitted limit of {max_mb} MB."
        )

    # Magic byte MIME verification
    if ext == ".pdf":
        if not file_bytes.startswith(b"%PDF-"):
            raise HTTPException(
                status_code=415,
                detail="Invalid file format: File header does not match PDF signature."
            )

def extract_text_from_pdf(
    file_bytes: bytes,
    max_chars: int = 100000,
    font_size_threshold: float = 2.0
) -> Tuple[str, bool, List[str], List[Dict[str, Any]]]:
    """
    Extracts text page by page using pypdf.
    Inspects rendering font sizes via visitor_text callbacks to detect
    micro-text / hidden font prompt injection attacks (< 2pt).
    Gracefully handles encrypted, corrupted, and image-only PDFs.
    """
    notices = []
    text_chunks = []
    stream = io.BytesIO(file_bytes)
    raw_micro_findings = []

    try:
        reader = PdfReader(stream)
        if reader.is_encrypted:
            try:
                # Attempt empty password decryption
                reader.decrypt("")
            except Exception:
                raise HTTPException(
                    status_code=422,
                    detail="Encrypted PDF: File is password-protected and cannot be read."
                )

        total_pages = len(reader.pages)
        if total_pages == 0:
            raise HTTPException(status_code=400, detail="PDF contains 0 pages.")

        for i, page in enumerate(reader.pages):
            page_micro_items = []

            def visitor(text, cm, tm, font_dict, font_size):
                if not text or not text.strip():
                    return
                try:
                    if font_size is not None:
                        f_sz = float(font_size)
                        scale_x = (tm[0]**2 + tm[1]**2)**0.5 if tm and len(tm) >= 4 else 1.0
                        scale_y = (tm[2]**2 + tm[3]**2)**0.5 if tm and len(tm) >= 4 else 1.0
                        eff_sz = abs(f_sz) * max(scale_x, scale_y)
                        
                        if eff_sz < font_size_threshold:
                            page_micro_items.append({
                                "text": text,
                                "font_size": eff_sz,
                                "page": i + 1
                            })
                except Exception:
                    pass

            try:
                page_text = page.extract_text(visitor_text=visitor) or ""
                if page_text.strip():
                    text_chunks.append(page_text)

                # Aggregate consecutive micro-text tokens on this page
                if page_micro_items:
                    curr_tokens = []
                    min_font = 999.0
                    for item in page_micro_items:
                        curr_tokens.append(item["text"])
                        min_font = min(min_font, item["font_size"])
                    full_micro_str = "".join(curr_tokens).strip()
                    if full_micro_str:
                        raw_micro_findings.append({
                            "page": i + 1,
                            "font_size": round(min_font, 2),
                            "text": full_micro_str
                        })
            except Exception as e:
                notices.append(f"Page {i+1} text extraction encountered an anomaly: {str(e)[:60]}")

    except (PdfReadError, FileNotDecryptedError) as e:
        raise HTTPException(status_code=422, detail=f"Corrupted or invalid PDF structure: {str(e)[:100]}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Unable to process PDF: {str(e)[:100]}")

    extracted_text = "\n\n".join(text_chunks).strip()
    if not extracted_text:
        raise HTTPException(
            status_code=400,
            detail="Document text is empty or non-extractable (e.g. scanned image-only PDF without embedded text layer)."
        )

    truncated = False
    if len(extracted_text) > max_chars:
        extracted_text = extracted_text[:max_chars]
        truncated = True
        notices.append(f"Text truncated at {max_chars} characters for security analysis.")

    return extracted_text, truncated, notices, raw_micro_findings

def extract_text_from_txt(file_bytes: bytes, max_chars: int = 100000) -> Tuple[str, bool, List[str]]:
    """
    Decodes plain text with UTF-8 and latin-1 fallbacks.
    """
    notices = []
    try:
        text = file_bytes.decode("utf-8")
    except UnicodeDecodeError:
        try:
            text = file_bytes.decode("latin-1")
            notices.append("Decoded with latin-1 fallback due to non-UTF-8 encoding.")
        except Exception as e:
            raise HTTPException(status_code=400, detail="Unable to decode text file with standard encodings.")

    extracted_text = text.strip()
    if not extracted_text:
        raise HTTPException(status_code=400, detail="Text file is empty or contains only whitespace.")

    truncated = False
    if len(extracted_text) > max_chars:
        extracted_text = extracted_text[:max_chars]
        truncated = True
        notices.append(f"Text truncated at {max_chars} characters for security analysis.")

    return extracted_text, truncated, notices

def split_into_passages(text: str, window_size: int = 300, overlap: int = 75) -> List[Dict[str, Any]]:
    """
    Partitions text into overlapping sliding passages (~500 chars with 100 char overlap)
    while recording exact start and end offsets.
    """
    passages = []
    text_len = len(text)
    start = 0
    idx = 0

    while start < text_len:
        end = min(start + window_size, text_len)
        
        # If not at the very end of text, try to snap to nearest sentence or space boundary
        if end < text_len:
            space_pos = text.rfind(" ", start + window_size // 2, end)
            if space_pos != -1:
                end = space_pos + 1

        passage_text = text[start:end]
        if passage_text.strip():
            passages.append({
                "index": idx,
                "start": start,
                "end": end,
                "text": passage_text
            })
            idx += 1

        if end >= text_len:
            break
        start = max(start + 1, end - overlap)

    return passages

def scan_document_content(
    filename: str,
    file_bytes: bytes
) -> Dict[str, Any]:
    """
    Orchestrates end-to-end document text extraction, font size inspection (< 2pt),
    and passage-level threat analysis.
    Document score = max(passage_score, micro_text_score) with context of flagged counts.
    """
    validate_file_metadata(filename, file_bytes, max_mb=settings.MAX_UPLOAD_SIZE_MB)
    ext = os.path.splitext(filename)[1].lower()

    if ext == ".pdf":
        text, truncated, notices, micro_findings = extract_text_from_pdf(
            file_bytes,
            max_chars=settings.MAX_DOCUMENT_EXTRACT_CHARS
        )
    else:
        text, truncated, notices = extract_text_from_txt(
            file_bytes,
            max_chars=settings.MAX_DOCUMENT_EXTRACT_CHARS
        )
        micro_findings = []

    pipeline = get_pipeline()
    raw_passages = split_into_passages(text)
    analyzed_passages = []

    highest_score = 0.0
    highest_classification = "Safe"
    highest_category = "Low"
    flagged_count = 0

    for p in raw_passages:
        res = pipeline.analyze_prompt(p["text"])
        p_score = res["risk_score"]
        p_class = res["classification"]
        p_spans = res["indicators"]

        if p_score > highest_score:
            highest_score = p_score
            highest_classification = p_class
            highest_category = res["risk_category"]

        if p_class in ["Suspicious", "Malicious"]:
            flagged_count += 1

        analyzed_passages.append({
            "index": p["index"],
            "start": p["start"],
            "end": p["end"],
            "text": p["text"],
            "risk_score": p_score,
            "classification": p_class,
            "indicators": p_spans
        })

    # Paragraph-level secondary scan: when the whole document fits in a single
    # sliding-window passage, injection phrases may be diluted by surrounding benign
    # text. Splitting on double-newline boundaries and scoring each paragraph in
    # isolation catches embedded attacks that window averaging misses.
    if len(raw_passages) <= 1:
        seen_texts = {p["text"].strip() for p in raw_passages}
        para_idx = len(analyzed_passages)
        for para in text.split("\n\n"):
            para = para.strip()
            if not para or para in seen_texts or len(para) < 20:
                continue
            seen_texts.add(para)
            res = pipeline.analyze_prompt(para)
            p_score = res["risk_score"]
            p_class = res["classification"]
            if p_score > highest_score:
                highest_score = p_score
                highest_classification = p_class
                highest_category = res["risk_category"]
            if p_class in ["Suspicious", "Malicious"]:
                flagged_count += 1
            start_off = text.find(para)
            analyzed_passages.append({
                "index": para_idx,
                "start": start_off,
                "end": start_off + len(para),
                "text": para,
                "risk_score": p_score,
                "classification": p_class,
                "indicators": res["indicators"]
            })
            para_idx += 1


    # Evaluate Micro-Text (< 2pt font size) Injection Findings
    processed_micro_findings = []
    for mf in micro_findings:
        mf_res = pipeline.analyze_prompt(mf["text"])
        is_attack = mf_res["classification"] in ["Suspicious", "Malicious"] or len(mf_res["indicators"]) > 0

        # Micro-text under 2pt is physically invisible to human readers on screens/paper.
        # If it contains an adversarial payload, score is critical (95-100).
        # Even if benign phrasing, embedding text under 2pt is an active evasion anomaly (>= 72.0).
        if is_attack:
            mf_score = max(mf_res["risk_score"], 95.0)
            mf_class = "Malicious"
            mf_cat = "Critical"
        else:
            mf_score = max(mf_res["risk_score"], 72.0)
            mf_class = "Suspicious"
            mf_cat = "High"

        processed_micro_findings.append({
            "page": mf["page"],
            "font_size": mf["font_size"],
            "text": mf["text"],
            "classification": mf_class,
            "risk_score": mf_score,
            "is_injection": is_attack
        })

        if mf_score > highest_score:
            highest_score = mf_score
            highest_classification = mf_class
            highest_category = mf_cat
            flagged_count += 1

        notices.append(
            f"Micro-Font Alert (Page {mf['page']}): Text rendered at {mf['font_size']}pt font (< 2pt threshold) detected. "
            f"Characters under 2pt are physically invisible to human readers and indicate hidden prompt injection evasion."
        )

        # Tag corresponding passages or attach indicator
        found_in_passage = False
        for p in analyzed_passages:
            if mf["text"] in p["text"]:
                found_in_passage = True
                p_start = p["start"] + p["text"].find(mf["text"])
                p["indicators"].append({
                    "category": "micro_text_injection",
                    "text": mf["text"][:120],
                    "start": p_start,
                    "end": p_start + len(mf["text"][:120]),
                    "revealed_by": f"PDF Font Inspector ({mf['font_size']}pt font < 2pt)"
                })
                if mf_score > p["risk_score"]:
                    p["risk_score"] = mf_score
                    p["classification"] = mf_class

        if not found_in_passage:
            analyzed_passages.append({
                "index": len(analyzed_passages),
                "start": 0,
                "end": len(mf["text"]),
                "text": mf["text"],
                "risk_score": mf_score,
                "classification": mf_class,
                "indicators": [{
                    "category": "micro_text_injection",
                    "text": mf["text"][:120],
                    "start": 0,
                    "end": len(mf["text"][:120]),
                    "revealed_by": f"PDF Font Inspector ({mf['font_size']}pt font < 2pt)"
                }]
            })

    # Summary Generation
    if processed_micro_findings:
        summary = (
            f"DOCUMENT FLAGGED (MICRO-TEXT INJECTION DETECTED): {len(processed_micro_findings)} hidden text passage(s) "
            f"rendered at unreadable font size (< 2pt) identified on Page(s) {', '.join(str(m['page']) for m in processed_micro_findings)}. "
            f"Peak risk: {highest_score}/100 ({highest_classification})."
        )
    elif flagged_count == 0:
        summary = f"Scanned {len(analyzed_passages)} passages across document; zero prompt injection threats identified."
    else:
        summary = (
            f"Document flagged: {flagged_count} of {len(analyzed_passages)} passages showed injection indicators. "
            f"Peak risk: {highest_score}/100 ({highest_classification})."
        )

    notices.append(LIMITATIONS_NOTICE)

    return {
        "filename": filename,
        "file_size_bytes": len(file_bytes),
        "total_passages": len(analyzed_passages),
        "flagged_passages_count": flagged_count,
        "document_risk_score": highest_score,
        "document_classification": highest_classification,
        "document_category": highest_category,
        "detection_summary": summary,
        "passages": analyzed_passages,
        "extracted_text": text,
        "truncated": truncated,
        "notices": notices,
        "model_version": pipeline.metadata.get("model_version", "v1.0.0_default"),
        "limitations": LIMITATIONS_NOTICE,
        "micro_text_findings": processed_micro_findings
    }
