"""
Main FastAPI Application Entrypoint.
Provides CORS middleware, in-memory rate limiting, safe exception handling,
and mounts all /api routes plus the bundled SPA static frontend.
"""
import time
from collections import defaultdict
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from promptshield.config import settings
from promptshield.database import init_db
from promptshield.ml.inference import get_pipeline
from promptshield.api import api_router

# Simple thread-safe in-memory rate limiter: max 120 requests per minute per IP
RATE_LIMIT_WINDOW = 60.0
MAX_REQUESTS_PER_WINDOW = 120
request_counts = defaultdict(list)

def check_rate_limit(client_ip: str) -> bool:
    now = time.time()
    timestamps = request_counts[client_ip]
    request_counts[client_ip] = [t for t in timestamps if now - t < RATE_LIMIT_WINDOW]
    if len(request_counts[client_ip]) >= MAX_REQUESTS_PER_WINDOW:
        return False
    request_counts[client_ip].append(now)
    return True

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: initialize database and warm up ML pipeline
    init_db()
    _ = get_pipeline()
    yield
    # Shutdown logic (if any)

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.VERSION,
    description=(
        "Local defensive analysis tool for detecting and mitigating adversarial prompt injection attacks. "
        "Built for SIH / College Demonstrations. Runs 100% locally with explainable machine learning."
    ),
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS Middleware limited to authorized frontend origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS if not settings.DEBUG else ["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Rate Limiting Middleware
@app.middleware("http")
async def rate_limiting_middleware(request: Request, call_next):
    if request.url.path.startswith("/api/analyze") or request.url.path.startswith("/api/scan-document"):
        client_ip = request.client.host if request.client else "127.0.0.1"
        if not check_rate_limit(client_ip):
            return JSONResponse(
                status_code=429,
                content={"detail": "Too many requests. Rate limit exceeded (120 req/min). Please try again shortly."}
            )
    response = await call_next(request)
    return response

# Safe Global Exception Handler: Never leak stack traces to client
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    if isinstance(exc, HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail}
        )
    print(f"Internal unhandled error on {request.method} {request.url.path}: {type(exc).__name__}")
    return JSONResponse(
        status_code=500,
        content={"detail": "An internal server error occurred while processing your request safely."}
    )

# Mount all API routes FIRST (before static files so /api always wins)
app.include_router(api_router)

# Resolve bundled static frontend via importlib.resources (installed wheel) or fallback paths
def _find_static_dir() -> Path | None:
    # 1. Package-installed static dir (inside the wheel)
    try:
        from importlib.resources import files
        candidate = Path(str(files("promptshield").joinpath("static")))
        if (candidate / "index.html").exists():
            return candidate
    except Exception:
        pass
    # 2. Source-tree: src/promptshield/static/
    here = Path(__file__).resolve().parent
    for rel in ("static", "../static"):
        candidate = (here / rel).resolve()
        if (candidate / "index.html").exists():
            return candidate
    # 3. Legacy: frontend/dist next to repo root
    candidate = Path(__file__).resolve().parents[3] / "frontend" / "dist"
    if (candidate / "index.html").exists():
        return candidate
    return None

STATIC_DIR = _find_static_dir()

if STATIC_DIR:
    assets_dir = STATIC_DIR / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")

    @app.get("/")
    async def serve_root():
        index_file = STATIC_DIR / "index.html"
        if index_file.is_file():
            return FileResponse(str(index_file))
        return {"service": settings.APP_NAME, "version": settings.VERSION, "docs": "/docs", "api": "/api/health"}

    @app.get("/{full_path:path}")
    async def serve_spa_routes(full_path: str):
        if full_path.startswith("api") or full_path in ("docs", "redoc", "openapi.json"):
            raise HTTPException(status_code=404, detail="Not Found")
        file_path = STATIC_DIR / full_path
        if full_path and file_path.is_file():
            return FileResponse(str(file_path))
        index_file = STATIC_DIR / "index.html"
        if index_file.is_file():
            return FileResponse(str(index_file))
        raise HTTPException(status_code=404, detail="Not Found")
else:
    @app.get("/")
    def root_status():
        return {
            "service": settings.APP_NAME,
            "version": settings.VERSION,
            "docs": "/docs",
            "api": "/api/health",
            "message": "Frontend not built. Run: promptshield build-frontend"
        }

    @app.get("/{full_path:path}")
    def spa_fallback(full_path: str):
        if full_path.startswith("api") or full_path in ("docs", "redoc", "openapi.json"):
            raise HTTPException(status_code=404, detail="Not Found")
        return {
            "service": settings.APP_NAME,
            "version": settings.VERSION,
            "route": full_path,
            "message": "Frontend not built. Run: promptshield build-frontend"
        }
