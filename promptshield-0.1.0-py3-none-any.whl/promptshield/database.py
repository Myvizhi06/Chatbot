"""
Database module using SQLite with parameterized queries only.
Stores scan audit records without sensitive full text by default.
"""
import sqlite3
import json
import uuid
import hashlib
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple

from promptshield.config import settings

def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(settings.DATABASE_PATH, timeout=10.0)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """
    Initializes the database schema and indexes.
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scans (
                id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                input_type TEXT NOT NULL,
                filename TEXT,
                input_length INTEGER NOT NULL,
                classification TEXT NOT NULL,
                risk_score REAL NOT NULL,
                risk_category TEXT NOT NULL,
                detection_summary TEXT NOT NULL,
                indicators_json TEXT,
                model_version TEXT NOT NULL,
                primary_model TEXT NOT NULL,
                model_results_json TEXT,
                content_preview TEXT,
                content_sha256 TEXT NOT NULL
            );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_scans_created_at ON scans (created_at DESC);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_scans_classification ON scans (classification);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_scans_input_type ON scans (input_type);")
        conn.commit()

def insert_scan(
    input_type: str,
    raw_text: str,
    classification: str,
    risk_score: float,
    risk_category: str,
    detection_summary: str,
    indicators: List[Dict[str, Any]],
    model_version: str,
    primary_model: str,
    model_results: List[Dict[str, Any]],
    filename: Optional[str] = None
) -> str:
    """
    Inserts a new scan record using parameterized query.
    Respects STORE_CONTENT_PREVIEW setting.
    """
    scan_id = str(uuid.uuid4())
    now_iso = datetime.now(timezone.utc).isoformat()
    content_hash = hashlib.sha256(raw_text.encode("utf-8")).hexdigest()
    
    preview = None
    if settings.STORE_CONTENT_PREVIEW and raw_text:
        preview = raw_text[:200].strip()

    indicators_json = json.dumps(indicators)
    model_results_json = json.dumps(model_results)
    input_len = len(raw_text)

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO scans (
                id, created_at, input_type, filename, input_length,
                classification, risk_score, risk_category, detection_summary,
                indicators_json, model_version, primary_model,
                model_results_json, content_preview, content_sha256
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            scan_id, now_iso, input_type, filename, input_len,
            classification, risk_score, risk_category, detection_summary,
            indicators_json, model_version, primary_model,
            model_results_json, preview, content_hash
        ))
        conn.commit()

    return scan_id

def get_scans(
    q: Optional[str] = None,
    classification: Optional[str] = None,
    input_type: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    limit: int = 50,
    offset: int = 0
) -> Tuple[List[Dict[str, Any]], int]:
    """
    Retrieves filtered scans with parameterized clauses and pagination.
    """
    query_parts = ["SELECT * FROM scans WHERE 1=1"]
    count_parts = ["SELECT COUNT(*) as cnt FROM scans WHERE 1=1"]
    params: List[Any] = []

    if classification:
        query_parts.append("AND classification = ?")
        count_parts.append("AND classification = ?")
        params.append(classification)

    if input_type:
        query_parts.append("AND input_type = ?")
        count_parts.append("AND input_type = ?")
        params.append(input_type)

    if date_from:
        query_parts.append("AND created_at >= ?")
        count_parts.append("AND created_at >= ?")
        params.append(date_from)

    if date_to:
        query_parts.append("AND created_at <= ?")
        count_parts.append("AND created_at <= ?")
        params.append(date_to)

    if q:
        query_parts.append("AND (detection_summary LIKE ? OR filename LIKE ?)")
        count_parts.append("AND (detection_summary LIKE ? OR filename LIKE ?)")
        search_pattern = f"%{q}%"
        params.extend([search_pattern, search_pattern])

    with get_connection() as conn:
        cursor = conn.cursor()
        # Count total
        cursor.execute(" ".join(count_parts), params)
        total = cursor.fetchone()["cnt"]

        # Order and pagination
        query_parts.append("ORDER BY created_at DESC LIMIT ? OFFSET ?")
        paginated_params = params + [limit, offset]
        cursor.execute(" ".join(query_parts), paginated_params)
        rows = [dict(row) for row in cursor.fetchall()]

    return rows, total

def get_scan_by_id(scan_id: str) -> Optional[Dict[str, Any]]:
    """
    Retrieves a single scan record by ID.
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
        row = cursor.fetchone()
        return dict(row) if row else None

def delete_scans(
    scan_ids: Optional[List[str]] = None,
    before_date: Optional[str] = None
) -> int:
    """
    Deletes specified scan records or all records if no filters provided.
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        if scan_ids:
            placeholders = ",".join("?" for _ in scan_ids)
            query = f"DELETE FROM scans WHERE id IN ({placeholders})"
            cursor.execute(query, scan_ids)
        elif before_date:
            cursor.execute("DELETE FROM scans WHERE created_at < ?", (before_date,))
        else:
            # Delete all
            cursor.execute("DELETE FROM scans")
        deleted_count = cursor.rowcount
        conn.commit()
    return deleted_count

def get_dashboard_metrics() -> Dict[str, Any]:
    """
    Computes real aggregation figures via SQL queries.
    Returns empty: true if total_scans == 0.
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as total FROM scans")
        total = cursor.fetchone()["total"]

        if total == 0:
            return {
                "empty": True,
                "total_scans": 0,
                "safe_count": 0,
                "suspicious_count": 0,
                "malicious_count": 0,
                "classification_counts": {"Safe": 0, "Suspicious": 0, "Malicious": 0},
                "category_counts": {"Low": 0, "Medium": 0, "High": 0, "Critical": 0},
                "score_histogram": [
                    {"range_label": "0-19", "count": 0},
                    {"range_label": "20-39", "count": 0},
                    {"range_label": "40-59", "count": 0},
                    {"range_label": "60-79", "count": 0},
                    {"range_label": "80-100", "count": 0}
                ],
                "daily_scans": [],
                "recent_scans": []
            }

        # Classification counts
        cursor.execute("""
            SELECT classification, COUNT(*) as cnt
            FROM scans
            GROUP BY classification
        """)
        class_rows = cursor.fetchall()
        class_map = {"Safe": 0, "Suspicious": 0, "Malicious": 0}
        for r in class_rows:
            class_map[r["classification"]] = r["cnt"]

        # Category counts
        cursor.execute("""
            SELECT risk_category, COUNT(*) as cnt
            FROM scans
            GROUP BY risk_category
        """)
        cat_rows = cursor.fetchall()
        cat_map = {"Low": 0, "Medium": 0, "High": 0, "Critical": 0}
        for r in cat_rows:
            cat_map[r["risk_category"]] = r["cnt"]

        # Histogram buckets
        cursor.execute("""
            SELECT
                SUM(CASE WHEN risk_score < 20 THEN 1 ELSE 0 END) as b1,
                SUM(CASE WHEN risk_score >= 20 AND risk_score < 40 THEN 1 ELSE 0 END) as b2,
                SUM(CASE WHEN risk_score >= 40 AND risk_score < 60 THEN 1 ELSE 0 END) as b3,
                SUM(CASE WHEN risk_score >= 60 AND risk_score < 80 THEN 1 ELSE 0 END) as b4,
                SUM(CASE WHEN risk_score >= 80 THEN 1 ELSE 0 END) as b5
            FROM scans
        """)
        h_row = cursor.fetchone()
        histogram = [
            {"range_label": "0-19", "count": h_row["b1"] or 0},
            {"range_label": "20-39", "count": h_row["b2"] or 0},
            {"range_label": "40-59", "count": h_row["b3"] or 0},
            {"range_label": "60-79", "count": h_row["b4"] or 0},
            {"range_label": "80-100", "count": h_row["b5"] or 0}
        ]

        # Daily scans (last 14 days)
        cursor.execute("""
            SELECT SUBSTR(created_at, 1, 10) as day, COUNT(*) as cnt
            FROM scans
            GROUP BY day
            ORDER BY day DESC
            LIMIT 14
        """)
        daily_rows = cursor.fetchall()
        daily_scans = [{"date": r["day"], "count": r["cnt"]} for r in reversed(daily_rows)]

        # Recent 10 scans
        cursor.execute("SELECT * FROM scans ORDER BY created_at DESC LIMIT 10")
        recent = [dict(r) for r in cursor.fetchall()]

    return {
        "empty": False,
        "total_scans": total,
        "safe_count": class_map.get("Safe", 0),
        "suspicious_count": class_map.get("Suspicious", 0),
        "malicious_count": class_map.get("Malicious", 0),
        "classification_counts": class_map,
        "category_counts": cat_map,
        "score_histogram": histogram,
        "daily_scans": daily_scans,
        "recent_scans": recent
    }
