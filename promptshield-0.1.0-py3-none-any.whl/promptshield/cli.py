"""
PromptShield CLI — entry point registered as `promptshield` in pyproject.toml.

Commands:
  promptshield serve         Start the API + frontend server
  promptshield version       Print version and model info
  promptshield check         Verify models load and DB is writable
  promptshield build-frontend  Build the React frontend into src/promptshield/static/
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import warnings
from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("promptshield")
    except Exception:
        from promptshield import __version__
        return __version__


def _check_sklearn_version(artifacts_dir: str) -> None:
    """Warn if installed sklearn version doesn't match the one used to train models."""
    meta_path = Path(artifacts_dir) / "metadata.json"
    if not meta_path.exists():
        return
    try:
        import sklearn
        with open(meta_path) as f:
            meta = json.load(f)
        trained_ver = meta.get("sklearn_version", "")
        installed_ver = sklearn.__version__
        if trained_ver and trained_ver != installed_ver:
            warnings.warn(
                f"sklearn version mismatch: models trained with {trained_ver}, "
                f"but {installed_ver} is installed. Joblib files may fail to load. "
                f"Pin scikit-learn=={trained_ver} for guaranteed compatibility.",
                UserWarning,
                stacklevel=2,
            )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_version(args: argparse.Namespace) -> int:  # noqa: ARG001
    print(f"promptshield {_get_version()}")
    # Also show model version if artifacts are available
    try:
        from promptshield.ml.inference import ARTIFACTS_DIR
        meta_path = Path(ARTIFACTS_DIR) / "metadata.json"
        if meta_path.exists():
            with open(meta_path) as f:
                meta = json.load(f)
            print(f"  model:    {meta.get('model_version', 'unknown')}")
            print(f"  phase:    {meta.get('phase', 'unknown')}")
            print(f"  sklearn:  {meta.get('sklearn_version', 'unknown')}")
            print(f"  primary:  {meta.get('primary_model', 'unknown')}")
            print(f"  artifacts:{ARTIFACTS_DIR}")
    except Exception as e:
        print(f"  (model info unavailable: {e})")
    return 0


def cmd_check(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Verify models load, DB is writable, and sklearn version matches."""
    ok = True
    print("promptshield check")
    print("-" * 40)

    # 1. sklearn version
    try:
        from promptshield.ml.inference import ARTIFACTS_DIR
        _check_sklearn_version(ARTIFACTS_DIR)
        print(f"[OK] artifacts dir: {ARTIFACTS_DIR}")
    except Exception as e:
        print(f"[FAIL] artifacts: {e}")
        ok = False

    # 2. Model loading
    try:
        from promptshield.ml.inference import DetectionPipeline
        pipeline = DetectionPipeline()
        loaded = [m for m in ["model_lr", "model_nb", "model_rf"] if getattr(pipeline, m) is not None]
        print(f"[OK] models loaded: {', '.join(m.replace('model_', '') for m in loaded)}")
        if not loaded:
            print("[FAIL] no models loaded — check artifacts directory")
            ok = False
    except Exception as e:
        print(f"[FAIL] model load failed: {e}")
        ok = False

    # 3. DB writable
    try:
        from promptshield.config import settings
        from promptshield.database import init_db
        init_db()
        db_path = settings.DATABASE_PATH
        print(f"[OK] database writable: {db_path}")
    except Exception as e:
        print(f"[FAIL] database: {e}")
        ok = False

    # 4. Static frontend
    from promptshield.main import STATIC_DIR
    if STATIC_DIR and (STATIC_DIR / "index.html").exists():
        print(f"[OK] frontend: {STATIC_DIR}")
    else:
        print("[!] frontend: not built (run `promptshield build-frontend`)")

    print("-" * 40)
    if ok:
        print("All checks passed.")
        return 0
    else:
        print("One or more checks failed.")
        return 1


def cmd_serve(args: argparse.Namespace) -> int:
    """Start uvicorn serving promptshield.main:app."""
    _check_sklearn_version_from_meta()
    try:
        import uvicorn
    except ImportError:
        print("ERROR: uvicorn is not installed. Run: pip install promptshield", file=sys.stderr)
        return 1

    print(f"Starting PromptShield {_get_version()} on http://{args.host}:{args.port}")
    print("  API docs:   /docs")
    print("  Health:     /api/health")

    uvicorn.run(
        "promptshield.main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level="info",
    )
    return 0


def _check_sklearn_version_from_meta() -> None:
    try:
        from promptshield.ml.inference import ARTIFACTS_DIR
        _check_sklearn_version(ARTIFACTS_DIR)
    except Exception:
        pass


def cmd_build_frontend(args: argparse.Namespace) -> int:  # noqa: ARG001
    """Build the React frontend and copy dist into src/promptshield/static/."""
    script = Path(__file__).resolve().parents[2] / "scripts" / "build_frontend.py"
    if not script.exists():
        # Installed wheel: look relative to cwd
        script = Path.cwd() / "scripts" / "build_frontend.py"
    if not script.exists():
        print(
            "ERROR: scripts/build_frontend.py not found.\n"
            "This command requires the source tree (not a wheel install).\n"
            "Clone the repository and run from there.",
            file=sys.stderr,
        )
        return 1
    import subprocess
    result = subprocess.run([sys.executable, str(script)])
    return result.returncode


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="promptshield",
        description="PromptShield — AI Prompt Injection Detection CLI",
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # serve
    p_serve = sub.add_parser("serve", help="Start the API + frontend server")
    p_serve.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    p_serve.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")
    p_serve.add_argument("--reload", action="store_true", help="Enable auto-reload (dev mode)")
    p_serve.set_defaults(func=cmd_serve)

    # version
    p_ver = sub.add_parser("version", help="Print version and model info")
    p_ver.set_defaults(func=cmd_version)

    # check
    p_check = sub.add_parser("check", help="Verify models load and DB is writable")
    p_check.set_defaults(func=cmd_check)

    # build-frontend
    p_build = sub.add_parser("build-frontend", help="Build React frontend into package static dir")
    p_build.set_defaults(func=cmd_build_frontend)

    return parser


def main() -> None:
    # Load .env if present (before anything else reads env vars)
    try:
        from dotenv import load_dotenv
        load_dotenv(override=False)  # don't override vars already set in shell
    except ImportError:
        pass

    parser = build_parser()
    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
